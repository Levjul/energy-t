# Evaluated checkpoint licenses

Verified from the primary Hugging Face model cards on 2026-08-16. The package
contains result records and code only; it does not redistribute model weights.

| Checkpoint | Exact revision | Owner | Upstream license | Primary source |
|---|---|---|---|---|
| `Qwen/Qwen2.5-7B-Instruct` | `a09a35458c702b33eeacc393d103063234e8bc28` | Qwen | Apache-2.0 | https://huggingface.co/Qwen/Qwen2.5-7B-Instruct/tree/a09a35458c702b33eeacc393d103063234e8bc28 |
| `mistralai/Mistral-7B-Instruct-v0.3` | `c170c708c41dac9275d15a8fff4eca08d52bab71` | Mistral AI | Apache-2.0 | https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.3/tree/c170c708c41dac9275d15a8fff4eca08d52bab71 |
| `Qwen/Qwen2.5-14B-Instruct` | `cf98f3b3bbb457ad9e2bb7baf9a0125b6b88caa8` | Qwen | Apache-2.0 | https://huggingface.co/Qwen/Qwen2.5-14B-Instruct/tree/cf98f3b3bbb457ad9e2bb7baf9a0125b6b88caa8 |
| `microsoft/phi-4` | `2db69c1c3e91a05d2c64a3185acfbaf36f744e25` | Microsoft | MIT | https://huggingface.co/microsoft/phi-4/tree/2db69c1c3e91a05d2c64a3185acfbaf36f744e25 |
| `mistralai/Mistral-Nemo-Instruct-2407` | `04d8a90549d23fc6bd7f642064003592df51e9b3` | Mistral AI / NVIDIA | Apache-2.0 | https://huggingface.co/mistralai/Mistral-Nemo-Instruct-2407/tree/04d8a90549d23fc6bd7f642064003592df51e9b3 |

These labels describe the upstream checkpoint repositories at the recorded
revisions. They are not a license for this supplement's newly created code,
analysis, or raw outputs.
