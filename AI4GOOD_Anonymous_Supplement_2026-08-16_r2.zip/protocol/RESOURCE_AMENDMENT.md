# Resource amendment: three-family 12–14B Colab run

Frozen: 2026-08-16, after a pre-result disk-capacity stop and before any
completed model raw output was accepted or inspected.

## Trigger

The first A100 attempt passed the runner and analyzer self-tests, then began the
first pinned model. Colab warned that its ephemeral disk used approximately
102.0 of 112.6 GB. The run was stopped before disk exhaustion. No complete
model raw JSON, combined summary, archive or behavioural classification from
that attempt is eligible for use.

## Allowed implementation change

The protocol, model order, exact model revisions, bfloat16 requirement, seven
facts, prompts, seed, orders, scoring, 84-row topology, cluster definition,
thresholds and interpretation boundary remain unchanged.

Only temporary model-cache management changes:

1. Each model loads from its own directory under
   `/content/field_hf_cache/<exact-model-slug>`.
2. The full run refuses to start unless the environment variable
   `FIELD_ALLOW_TEMP_CACHE_DELETE` equals the exact value `YES`.
3. After a model finishes, its raw JSON is written first.
4. The runner reopens that raw JSON and requires `state=complete` plus exact
   pinned model metadata.
5. The runner computes and prints the raw file SHA-256.
6. Only then may it remove that model's exact temporary cache directory.
7. The guard refuses any path whose resolved parent is not exactly
   `/content/field_hf_cache` or whose leaf is not the exact model slug.

No PC file, `[local Field workspace]` file, Google Drive file, notebook, raw result or final
archive is a cleanup target.

## User gate

The user explicitly approved deletion of the temporary Colab model cache
between completed models. The amendment is active for the current A100 run.
The approval does not extend to PC files, `[local Field workspace]`, Google Drive, notebooks,
raw results or archives.

## Current package hashes

- runner SHA-256:
  `9d66381309d23629c86415bc73c175191a9dc006b96ad104507d912d894a649c`
- analyzer SHA-256:
  `2d7da776a5dbc03379e2defcd90a2b9b30500aa686bc0e39cd3af736f7d0bf6c`

Both files compile. The runner design/gate self-test and the analyzer topology,
duplicate-key, directional-gate and three-family-classification self-tests pass
locally and in the fresh Colab runtime after this amendment.
