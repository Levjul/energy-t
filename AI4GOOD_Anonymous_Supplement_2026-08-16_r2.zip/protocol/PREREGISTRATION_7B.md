# Preregistration: context-induced sequence preference replication

Frozen: 2026-08-16 (Europe/Zurich)

## Evidence boundary

The existing confirmatory core is one model and one protocol:
Qwen2.5-7B-Instruct, seven facts, three fixed orders, cumulative context sizes
one through seven, and 84 matched compatible/conflicting comparisons. This
replication is evaluated separately. It must not be pooled retrospectively with
the existing 84 pairs.

## Fixed models

1. Anchor: `Qwen/Qwen2.5-7B-Instruct`, revision
   `a09a35458c702b33eeacc393d103063234e8bc28`.
2. Distinct family: `mistralai/Mistral-7B-Instruct-v0.3`, revision
   `c170c708c41dac9275d15a8fff4eca08d52bab71`.

Both repositories were public, ungated, Apache-2.0 model cards at freeze time.
The exact revisions are fixed before the run. Models are loaded sequentially in
bfloat16. A quantized fallback is a different exploratory protocol and cannot
receive a confirmatory gate status.

## Fixed protocol

- Exact seven facts, correct answers, false alternatives, system instruction,
  context statements, seed `20260716`, three orders, and context sizes from the
  original Qwen script.
- Each model uses its own pinned official chat template with the same system
  and user message contents.
- For each matched prompt, teacher-force the complete predefined correct and
  false answer sequences.
- Correct-answer advantage:
  `C = log P(correct sequence) - log P(false sequence)`.
- Paired shift:
  `S = C_conflicting - C_compatible`; negative values are in the predicted
  direction.
- Greedy decoding is retained only for the exact-text blind-spot subset.
- No entropy, hidden-state geometry, energy, cost, cascade, classifier, Part 3,
  or social-harm claim is tested here.

## Unit structure

The script must produce exactly 84 pairs per model. They are nested. The
secondary robustness unit is the 21 `(repeat, fact)` clusters; each cluster
contains the context sizes in which that fact appears. Pair counts are reported
descriptively and are not treated as 84 independent facts.

## Preregistered gates

### Structural gate

Pass only if the model revision, prompt construction, 84 pair keys, all scores,
environment metadata, start/end time, and raw JSON are present. Any loading,
tokenization, truncation, out-of-memory, non-finite score, pairing, or write
failure is a **technical failure**, not a behavioural result.

### Directional gate per model

- **Nominal pass:** at least 80/84 negative pair shifts, at least 18/21 negative
  cluster means, and negative median pair and cluster shifts.
- **Tolerance pass:** at least 67/84 negative pair shifts, at least 16/21
  negative cluster means, and negative median pair and cluster shifts.
- **Borderline/transition:** negative medians and at least 11/21 negative
  clusters, but the tolerance gate is missed.
- **Out of tolerance but analyzable:** structurally valid output outside the
  above zones.

These are descriptive tolerance zones for a nested design, not a replacement
for a hierarchical uncertainty analysis.

### Anchor numerical-reproduction gate

For Qwen only, compare with the frozen A100 reference mean `-21.269761556990083`.

- **Nominal:** directional nominal pass and absolute mean difference at most
  `1.0` log-probability unit.
- **Tolerance:** directional tolerance pass and absolute mean difference at
  most `2.0` units.
- Otherwise report the exact distance and do not call it numerical
  reproduction.

### Exact-text blind-spot gate

This secondary gate is evaluable only if at least ten pairs produce identical
greedy text in compatible and conflicting conditions. It passes nominally only
when every such pair has `S < 0`. Smaller subsets are reported as
`not_evaluable`, not as failure or confirmation.

## Permitted interpretation

- A Qwen anchor pass supports numerical/procedural reproduction at the stated
  margin.
- A Mistral pass supports cross-family observation for this fixed protocol.
- A missed gate limits the claim strength but does not erase structurally valid
  observations or failure modes.
- Even two model families do not justify a universal model claim.

## Safety factor

The planned claim is only descriptive robustness under controlled false
context. Causal mechanism, naturalistic deployment, universal safety, physical
energy, and societal claims require substantially more evidence and remain
outside this package regardless of gate status.

