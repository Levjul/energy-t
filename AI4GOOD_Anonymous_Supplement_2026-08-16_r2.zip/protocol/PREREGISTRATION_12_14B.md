# Preregistration: three-family 12--14B extension

Frozen: 2026-08-16, before any behavioural execution of these model revisions.

## Purpose

Test whether the already observed conflicting-context shift is descriptively
robust across three independent open-weight model families near 14B parameters.
This is a separate extension. It does not replace, pool with, or retroactively
modify the completed 7B replication.

## Fixed models

| Model | Family | Parameters | Revision | Access |
|---|---|---:|---|---|
| `Qwen/Qwen2.5-14B-Instruct` | Qwen2 | 14,770,033,664 | `cf98f3b3bbb457ad9e2bb7baf9a0125b6b88caa8` | public, ungated, Apache-2.0 |
| `microsoft/phi-4` | Phi | 14,659,507,200 | `2db69c1c3e91a05d2c64a3185acfbaf36f744e25` | public, ungated, MIT |
| `mistralai/Mistral-Nemo-Instruct-2407` | Mistral | 12,247,782,400 | `04d8a90549d23fc6bd7f642064003592df51e9b3` | public, ungated, Apache-2.0 |

The revisions were read from the Hugging Face model API before execution.
Models load sequentially in native bfloat16 on CUDA. There is no quantized,
CPU, paid-API, alternate-model or silent revision fallback.

## Fixed protocol

- Keep the exact seven facts, correct alternatives, false alternatives, system
  wording, seed `20260716`, three orders and context sizes 1--7 from the
  completed protocol.
- For each model, write exactly 84 paired rows in 21 nested `(repeat, fact)`
  clusters.
- Score complete target and false-answer token sequences with teacher-forced
  log probabilities.
- Contrast: `C = log P(correct sequence) - log P(false sequence)`.
- Shift: `S = C_conflicting - C_compatible`; negative is the predicted
  direction.
- Greedy output is secondary and is used only to identify identical-text pairs.
- Record model revision, raw prompts by SHA-256, complete scores, environment,
  GPU, start/end time and elapsed seconds.

## Structural gate

Each model must have its exact pinned metadata, all 84 unique row keys, finite
scores, complete raw JSON and environment metadata. Loading, tokenization,
truncation, out-of-memory, non-finite arithmetic, pairing or write failure is a
technical failure for that model and prevents a complete three-family result.

## Directional gate per model

- **Nominal pass:** at least 80/84 negative pairs, at least 18/21 negative
  cluster means, and negative median pair and cluster shifts.
- **Tolerance pass:** at least 67/84 negative pairs, at least 16/21 negative
  cluster means, and negative median pair and cluster shifts.
- **Borderline/transition:** negative medians and at least 11/21 negative
  clusters, but the tolerance gate is missed.
- **Out of tolerance but analyzable:** structurally valid output outside those
  zones.

These are preregistered descriptive tolerance zones for a nested design, not
84 independent trials and not a substitute for hierarchical uncertainty.

## Same-text gate

For a model with at least ten identical compatible/conflicting greedy outputs,
the gate is nominal only if every corresponding shift is negative. Fewer than
ten is `not_evaluable`; any non-negative member is `mixed`.

## Three-family classification

- **Strong descriptive replication:** all three models pass nominally.
- **Robust within tolerance:** all three models pass at least tolerance and at
  least two pass nominally.
- **Mixed:** all outputs are structurally valid but any model is borderline or
  outside tolerance, or fewer than two are nominal.
- **Incomplete/technical:** any pinned model lacks a structurally valid output.

No threshold is changed after seeing results. All misses, positive shifts and
technical failures remain visible.

## Interpretation and safety factor

A strong or within-tolerance result permits only this statement: in the fixed
synthetic protocol, the predicted shift is observed descriptively across these
three 12--14B model families. A comparison with the completed 7B run is
exploratory because model families, sizes and instruction tuning are not a
controlled scale intervention.

No outcome permits a universal-model, causal-mechanism, physical-energy, cost,
deployment, universal-safety or social-impact claim. External submission and
any paid compute action remain separate user gates.
