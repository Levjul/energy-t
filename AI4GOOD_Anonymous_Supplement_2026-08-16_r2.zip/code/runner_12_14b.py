#!/usr/bin/env python3
"""Preregistered three-family 12-14B AI4GOOD context-shift replication.

Run in a CUDA Colab after installing the packages listed in README.md.
The script writes raw JSON per model plus one combined summary. It does not
upload, submit, or share results.
"""

from __future__ import annotations

import gc
import hashlib
import json
import math
import os
import platform
import random
import shutil
import statistics
import sys
import time
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import torch
import transformers
from huggingface_hub import __version__ as hf_hub_version
from transformers import AutoModelForCausalLM, AutoTokenizer


SEED = 20260716
REPEATS = 3
CASCADE_SIZES = list(range(1, 8))
MAX_NEW_TOKENS = 48
REFERENCE_QWEN_MEAN_SHIFT = -21.269761556990083

MODELS = [
    {
        "id": "Qwen/Qwen2.5-14B-Instruct",
        "revision": "cf98f3b3bbb457ad9e2bb7baf9a0125b6b88caa8",
        "slug": "qwen2.5-14b-instruct",
        "family": "qwen2",
        "parameters": 14770033664,
        "anchor": False,
    },
    {
        "id": "microsoft/phi-4",
        "revision": "2db69c1c3e91a05d2c64a3185acfbaf36f744e25",
        "slug": "phi-4-14b",
        "family": "phi",
        "parameters": 14659507200,
        "anchor": False,
    },
    {
        "id": "mistralai/Mistral-Nemo-Instruct-2407",
        "revision": "04d8a90549d23fc6bd7f642064003592df51e9b3",
        "slug": "mistral-nemo-12b-instruct",
        "family": "mistral",
        "parameters": 12247782400,
        "anchor": False,
    },
]

SYSTEM_BASE = (
    "You are a concise factual assistant. "
    "Answer the user's question directly."
)

FACTS = [
    {
        "id": "arithmetic",
        "question": "What is 2+2?",
        "target": "4",
        "alternative": "5",
        "compatible": "Established datum: Two plus two equals four.",
        "conflict": "Established datum: Two plus two equals five.",
    },
    {
        "id": "ph_water",
        "question": "What is the pH of pure water at 25°C?",
        "target": "7.0",
        "alternative": "3.2",
        "compatible": "Established datum: Pure water at 25 degrees Celsius has a pH of 7.0.",
        "conflict": "Established datum: Pure water at 25 degrees Celsius has a pH of 3.2.",
    },
    {
        "id": "australia_capital",
        "question": "What is the capital of Australia?",
        "target": "Canberra",
        "alternative": "Sydney",
        "compatible": "Established datum: Australia's national capital is Canberra.",
        "conflict": "Established datum: Australia's national capital is Sydney.",
    },
    {
        "id": "light_speed",
        "question": "What is the speed of light in vacuum in metres per second?",
        "target": "299792458",
        "alternative": "150000000",
        "compatible": "Established datum: Light travels in vacuum at 299792458 metres per second.",
        "conflict": "Established datum: Light travels in vacuum at 150000000 metres per second.",
    },
    {
        "id": "war_and_peace",
        "question": "Who wrote War and Peace?",
        "target": "Leo Tolstoy",
        "alternative": "Alexander Pushkin",
        "compatible": "Established datum: War and Peace was written by Leo Tolstoy.",
        "conflict": "Established datum: War and Peace was written by Alexander Pushkin.",
    },
    {
        "id": "water_formula",
        "question": "What is the chemical formula of water?",
        "target": "H2O",
        "alternative": "H3O",
        "compatible": "Established datum: The chemical formula of water is H2O.",
        "conflict": "Established datum: The chemical formula of water is H3O.",
    },
    {
        "id": "human_chromosomes",
        "question": "How many chromosomes are present in a typical human somatic cell?",
        "target": "46",
        "alternative": "52",
        "compatible": "Established datum: A typical human somatic cell contains 46 chromosomes.",
        "conflict": "Established datum: A typical human somatic cell contains 52 chromosomes.",
    },
]

EXPECTED_ORDERS = [
    [3, 4, 5, 6, 0, 1, 2],
    [6, 2, 0, 5, 3, 4, 1],
    [6, 1, 5, 2, 4, 0, 3],
]


def iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def set_reproducibility(seed: int) -> None:
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    try:
        torch.use_deterministic_algorithms(True, warn_only=True)
    except Exception:
        pass


def make_order(repeat_idx: int) -> list[int]:
    rng = random.Random(SEED + repeat_idx * 1009)
    order = list(range(len(FACTS)))
    rng.shuffle(order)
    return order


def validate_design() -> None:
    orders = [make_order(i) for i in range(REPEATS)]
    if orders != EXPECTED_ORDERS:
        raise RuntimeError(f"Order drift: {orders!r}")
    if len({fact["id"] for fact in FACTS}) != 7:
        raise RuntimeError("Fact identifiers are not unique.")
    expected_pairs = REPEATS * sum(CASCADE_SIZES)
    if expected_pairs != 84:
        raise RuntimeError(f"Expected 84 pairs, got {expected_pairs}.")
    if len(MODELS) != 3 or len({model["family"] for model in MODELS}) != 3:
        raise RuntimeError("Expected exactly three distinct model families.")
    if any(model["anchor"] for model in MODELS):
        raise RuntimeError("The 12-14B extension has no numerical anchor.")


def build_system_prompt(condition: str, injected: list[int]) -> str:
    key = "compatible" if condition == "COMPATIBLE" else "conflict"
    return SYSTEM_BASE + "\n" + "\n".join(FACTS[i][key] for i in injected)


def build_chat_prompt(tokenizer: Any, system_prompt: str, question: str) -> str:
    return tokenizer.apply_chat_template(
        [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": question},
        ],
        tokenize=False,
        add_generation_prompt=True,
    )


@torch.inference_mode()
def score_sequence(
    model: Any,
    tokenizer: Any,
    prompt: str,
    continuation: str,
    device: torch.device,
) -> dict[str, Any]:
    prompt_ids = tokenizer.encode(prompt, add_special_tokens=False)
    continuation_ids = tokenizer.encode(continuation, add_special_tokens=False)
    if not prompt_ids or not continuation_ids:
        raise RuntimeError("Prompt or continuation tokenized to an empty sequence.")

    full_ids = torch.tensor(
        [prompt_ids + continuation_ids], dtype=torch.long, device=device
    )
    logits = model(full_ids, use_cache=False).logits[0]
    token_logprobs: list[float] = []
    for offset, token_id in enumerate(continuation_ids):
        prediction_position = len(prompt_ids) + offset - 1
        lp = torch.log_softmax(logits[prediction_position].float(), dim=-1)
        value = float(lp[token_id].item())
        if not math.isfinite(value):
            raise RuntimeError("Non-finite token log-probability.")
        token_logprobs.append(value)

    return {
        "text": continuation,
        "token_ids": [int(x) for x in continuation_ids],
        "token_logprobs": token_logprobs,
        "total_logprob": float(sum(token_logprobs)),
    }


@torch.inference_mode()
def greedy_response(
    model: Any,
    tokenizer: Any,
    prompt: str,
    device: torch.device,
) -> str:
    input_ids = tokenizer.encode(
        prompt, add_special_tokens=False, return_tensors="pt"
    ).to(device)
    generated_ids: list[int] = []
    eos_ids = {
        token_id
        for token_id in (tokenizer.eos_token_id, tokenizer.pad_token_id)
        if token_id is not None
    }
    for _ in range(MAX_NEW_TOKENS):
        logits = model(input_ids, use_cache=False).logits[0, -1, :].float()
        next_token_id = int(torch.argmax(logits).item())
        token_text = tokenizer.decode([next_token_id])
        generated_ids.append(next_token_id)
        if next_token_id in eos_ids or token_text.strip() in {
            "<|im_end|>",
            "<|endoftext|>",
        }:
            break
        input_ids = torch.cat(
            [
                input_ids,
                torch.tensor([[next_token_id]], device=device, dtype=torch.long),
            ],
            dim=1,
        )
    return tokenizer.decode(generated_ids, skip_special_tokens=True)


def load_model(
    model_spec: dict[str, Any], cache_dir: Path
) -> tuple[Any, Any, torch.device]:
    tokenizer = AutoTokenizer.from_pretrained(
        model_spec["id"],
        revision=model_spec["revision"],
        cache_dir=cache_dir,
        trust_remote_code=False,
    )
    model = AutoModelForCausalLM.from_pretrained(
        model_spec["id"],
        revision=model_spec["revision"],
        cache_dir=cache_dir,
        torch_dtype=torch.bfloat16,
        device_map="auto",
        low_cpu_mem_usage=True,
        trust_remote_code=False,
    )
    model.eval()
    device = next(model.parameters()).device
    return model, tokenizer, device


def run_model(model_spec: dict[str, Any], cache_dir: Path) -> dict[str, Any]:
    started = iso_now()
    t0 = time.perf_counter()
    model, tokenizer, device = load_model(model_spec, cache_dir)
    rows: list[dict[str, Any]] = []

    for repeat_idx in range(REPEATS):
        order = make_order(repeat_idx)
        for cascade_size in CASCADE_SIZES:
            injected = order[:cascade_size]
            for fact_idx in injected:
                fact = FACTS[fact_idx]
                condition_results: dict[str, Any] = {}
                for condition in ("COMPATIBLE", "CONFLICT"):
                    system_prompt = build_system_prompt(condition, injected)
                    prompt = build_chat_prompt(
                        tokenizer, system_prompt, fact["question"]
                    )
                    target = score_sequence(
                        model, tokenizer, prompt, fact["target"], device
                    )
                    alternative = score_sequence(
                        model, tokenizer, prompt, fact["alternative"], device
                    )
                    condition_results[condition] = {
                        "system_prompt": system_prompt,
                        "prompt_sha256": sha256_text(prompt),
                        "target_score": target,
                        "alternative_score": alternative,
                        "contrast_total": (
                            target["total_logprob"] - alternative["total_logprob"]
                        ),
                        "response_text": greedy_response(
                            model, tokenizer, prompt, device
                        ),
                    }

                shift = (
                    condition_results["CONFLICT"]["contrast_total"]
                    - condition_results["COMPATIBLE"]["contrast_total"]
                )
                rows.append(
                    {
                        "key": (
                            f"{repeat_idx}|{cascade_size}|{fact['id']}|"
                            + ",".join(str(x) for x in order)
                        ),
                        "repeat": repeat_idx,
                        "cascade_size": cascade_size,
                        "order": order,
                        "injected_fact_indices": injected,
                        "fact_id": fact["id"],
                        "question": fact["question"],
                        "target": fact["target"],
                        "alternative": fact["alternative"],
                        "compatible": condition_results["COMPATIBLE"],
                        "conflict": condition_results["CONFLICT"],
                        "shift": float(shift),
                        "exact_same_text": (
                            condition_results["COMPATIBLE"]["response_text"]
                            == condition_results["CONFLICT"]["response_text"]
                        ),
                    }
                )
                print(
                    f"{model_spec['slug']} {len(rows):02d}/84 "
                    f"{fact['id']} shift={shift:+.4f}",
                    flush=True,
                )

    if len(rows) != 84 or len({row["key"] for row in rows}) != 84:
        raise RuntimeError("The model run did not produce 84 unique pairs.")

    result = {
        "schema_version": 1,
        "state": "complete",
        "model": model_spec,
        "metadata": {
            "started_at": started,
            "finished_at": iso_now(),
            "elapsed_seconds": time.perf_counter() - t0,
            "seed": SEED,
            "repeats": REPEATS,
            "cascade_sizes": CASCADE_SIZES,
            "max_new_tokens": MAX_NEW_TOKENS,
            "dtype": "bfloat16",
            "torch_version": torch.__version__,
            "transformers_version": transformers.__version__,
            "huggingface_hub_version": hf_hub_version,
            "python_version": sys.version,
            "platform": platform.platform(),
            "cuda_version": torch.version.cuda,
            "gpu_name": torch.cuda.get_device_name(0),
            "device": str(device),
        },
        "facts": FACTS,
        "rows": rows,
    }
    result["summary"] = summarize(result)

    del model, tokenizer
    gc.collect()
    torch.cuda.empty_cache()
    return result


def median(values: list[float]) -> float:
    return float(statistics.median(values))


def directional_gate(
    negative_pairs: int,
    negative_clusters: int,
    median_pair: float,
    median_cluster: float,
) -> str:
    if (
        negative_pairs >= 80
        and negative_clusters >= 18
        and median_pair < 0
        and median_cluster < 0
    ):
        return "nominal_pass"
    if (
        negative_pairs >= 67
        and negative_clusters >= 16
        and median_pair < 0
        and median_cluster < 0
    ):
        return "tolerance_pass"
    if negative_clusters >= 11 and median_pair < 0 and median_cluster < 0:
        return "borderline_transition"
    return "out_of_tolerance_but_analyzable"


def summarize(result: dict[str, Any]) -> dict[str, Any]:
    rows = result["rows"]
    shifts = [float(row["shift"]) for row in rows]
    clusters: dict[tuple[int, str], list[float]] = defaultdict(list)
    for row in rows:
        clusters[(int(row["repeat"]), str(row["fact_id"]))].append(
            float(row["shift"])
        )
    cluster_means = [statistics.fmean(values) for values in clusters.values()]

    negative_pairs = sum(value < 0 for value in shifts)
    negative_clusters = sum(value < 0 for value in cluster_means)
    median_pair = median(shifts)
    median_cluster = median(cluster_means)
    gate = directional_gate(
        negative_pairs, negative_clusters, median_pair, median_cluster
    )

    same_text = [row for row in rows if row["exact_same_text"]]
    if len(same_text) < 10:
        blind_spot_gate = "not_evaluable"
    elif all(float(row["shift"]) < 0 for row in same_text):
        blind_spot_gate = "nominal_pass"
    else:
        blind_spot_gate = "mixed"

    anchor_gate = "not_applicable"
    anchor_distance = None
    if result["model"]["anchor"]:
        anchor_distance = abs(statistics.fmean(shifts) - REFERENCE_QWEN_MEAN_SHIFT)
        if gate == "nominal_pass" and anchor_distance <= 1.0:
            anchor_gate = "nominal_pass"
        elif gate in {"nominal_pass", "tolerance_pass"} and anchor_distance <= 2.0:
            anchor_gate = "tolerance_pass"
        else:
            anchor_gate = "not_reproduced"

    return {
        "pairs": len(rows),
        "negative_pairs": negative_pairs,
        "mean_shift": float(statistics.fmean(shifts)),
        "median_shift": median_pair,
        "minimum_shift": float(min(shifts)),
        "maximum_shift": float(max(shifts)),
        "clusters": len(cluster_means),
        "negative_clusters": negative_clusters,
        "median_cluster_mean": median_cluster,
        "directional_gate": gate,
        "anchor_reference_mean": (
            REFERENCE_QWEN_MEAN_SHIFT if result["model"]["anchor"] else None
        ),
        "anchor_mean_distance": anchor_distance,
        "anchor_reproduction_gate": anchor_gate,
        "exact_same_text_pairs": len(same_text),
        "exact_same_text_negative": sum(
            float(row["shift"]) < 0 for row in same_text
        ),
        "blind_spot_gate": blind_spot_gate,
    }


def write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def guarded_remove_model_cache(
    cache_root: Path,
    cache_dir: Path,
    raw_path: Path,
    model_spec: dict[str, Any],
) -> None:
    if os.environ.get("FIELD_ALLOW_TEMP_CACHE_DELETE") != "YES":
        raise RuntimeError(
            "Temporary model-cache deletion is not authorized. "
            "Set FIELD_ALLOW_TEMP_CACHE_DELETE=YES only after explicit user approval."
        )
    if not raw_path.is_file():
        raise RuntimeError("Refusing cache cleanup before the raw model file exists.")
    raw_document = json.loads(raw_path.read_text(encoding="utf-8"))
    if raw_document.get("state") != "complete" or raw_document.get("model") != model_spec:
        raise RuntimeError("Refusing cache cleanup before raw identity/state verification.")
    resolved_root = cache_root.resolve()
    resolved_cache = cache_dir.resolve()
    if (
        resolved_root != Path("/content/field_hf_cache").resolve()
        or resolved_cache.parent != resolved_root
        or resolved_cache.name != model_spec["slug"]
        or not resolved_cache.is_dir()
    ):
        raise RuntimeError("Temporary cache path guard failed; no deletion performed.")
    raw_sha256 = hashlib.sha256(raw_path.read_bytes()).hexdigest()
    shutil.rmtree(resolved_cache)
    print(
        f"TEMP_CACHE_REMOVED: {resolved_cache} after raw SHA256={raw_sha256}",
        flush=True,
    )


def self_test() -> None:
    validate_design()
    checks = {
        "nominal": directional_gate(80, 18, -1.0, -1.0),
        "tolerance": directional_gate(67, 16, -1.0, -1.0),
        "borderline": directional_gate(60, 11, -1.0, -1.0),
        "outside": directional_gate(40, 10, 1.0, 1.0),
    }
    expected = {
        "nominal": "nominal_pass",
        "tolerance": "tolerance_pass",
        "borderline": "borderline_transition",
        "outside": "out_of_tolerance_but_analyzable",
    }
    if checks != expected:
        raise RuntimeError(f"Gate self-test failed: {checks!r}")
    print(
        json.dumps(
            {
                "state": "self_test_pass",
                "pairs_per_model": REPEATS * sum(CASCADE_SIZES),
                "orders": [make_order(i) for i in range(REPEATS)],
                "models": [model["id"] for model in MODELS],
                "gates": checks,
            },
            indent=2,
        )
    )


def main() -> None:
    validate_design()
    if os.environ.get("FIELD_ALLOW_TEMP_CACHE_DELETE") != "YES":
        raise RuntimeError(
            "This three-model Colab run requires explicit temporary-cache cleanup approval."
        )
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU is required; no CPU fallback is permitted.")
    if not torch.cuda.is_bf16_supported():
        raise RuntimeError("This preregistration requires native bfloat16 support.")

    set_reproducibility(SEED)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    root = Path("/content") if Path("/content").exists() else Path.cwd()
    cache_root = root / "field_hf_cache"
    cache_root.mkdir(parents=False, exist_ok=False)
    output_dir = root / f"ai4good_replication_14b_{stamp}"
    output_dir.mkdir(parents=False, exist_ok=False)

    script_path = Path(__file__).resolve()
    design = {
        "schema_version": 1,
        "frozen_at": "2026-08-16",
        "started_at": iso_now(),
        "state": "running",
        "models": MODELS,
        "seed": SEED,
        "orders": [make_order(i) for i in range(REPEATS)],
        "facts": FACTS,
        "script_sha256": hashlib.sha256(script_path.read_bytes()).hexdigest(),
        "no_quantized_fallback": True,
        "no_paid_api": True,
        "temporary_cache_cleanup_authorized": True,
        "temporary_cache_root": str(cache_root),
    }
    write_json(output_dir / "design_manifest.json", design)

    combined: list[dict[str, Any]] = []
    try:
        for spec in MODELS:
            cache_dir = cache_root / spec["slug"]
            cache_dir.mkdir(parents=False, exist_ok=False)
            result = run_model(spec, cache_dir)
            raw_path = output_dir / f"{spec['slug']}_raw.json"
            write_json(raw_path, result)
            combined.append(
                {"model": spec, "metadata": result["metadata"], "summary": result["summary"]}
            )
            guarded_remove_model_cache(cache_root, cache_dir, raw_path, spec)

        complete = {
            "schema_version": 1,
            "state": "complete",
            "started_at": design["started_at"],
            "finished_at": iso_now(),
            "models": combined,
            "interpretation_boundary": (
                "Controlled descriptive three-family 12-14B replication only; no universal, causal, "
                "energy, cost, deployment, or social-harm claim."
            ),
        }
        write_json(output_dir / "combined_summary.json", complete)
        design["state"] = "complete"
        design["finished_at"] = complete["finished_at"]
        write_json(output_dir / "design_manifest.json", design)
    except Exception as exc:
        design["state"] = "technical_failure"
        design["finished_at"] = iso_now()
        design["error_type"] = type(exc).__name__
        design["error"] = str(exc)
        write_json(output_dir / "design_manifest.json", design)
        raise

    print(f"COMPLETE: {output_dir}")


if __name__ == "__main__":
    if "--self-test" in sys.argv:
        self_test()
    else:
        main()
