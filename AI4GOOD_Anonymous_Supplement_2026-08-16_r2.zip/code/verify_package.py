#!/usr/bin/env python3
"""Offline integrity, anonymity, and numerical verification for the supplement."""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
TEXT_SUFFIXES = {".py", ".md", ".json", ".txt", ".csv"}
FORBIDDEN = {
    "email": re.compile(r"(?i)[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}"),
    "windows_user_path": re.compile(r"(?i)C:\\\\Users\\\\[^\\\\\s\"']+"),
    "field_absolute_path": re.compile(r"(?i)D:\\\\field"),
    "hf_token": re.compile(r"(?i)\bhf_[a-z0-9]{20,}\b"),
    "openai_like_key": re.compile(r"(?i)\bsk-[-_a-z0-9]{16,}\b"),
    "google_like_key": re.compile(r"\bAIza[-_A-Za-z0-9]{16,}\b"),
}


class PackageError(RuntimeError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise PackageError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def run_json(*args: str) -> dict[str, Any]:
    completed = subprocess.run(
        [sys.executable, *args],
        cwd=ROOT,
        capture_output=True,
        text=True,
        encoding="utf-8",
        check=False,
    )
    require(completed.returncode == 0, completed.stderr or completed.stdout)
    return json.loads(completed.stdout)


def verify() -> dict[str, Any]:
    manifest_path = ROOT / "MANIFEST.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    expected = {item["path"]: item for item in manifest["files"]}
    actual = {
        path.relative_to(ROOT).as_posix(): path
        for path in ROOT.rglob("*")
        if path.is_file() and path != manifest_path
    }
    require(set(actual) == set(expected), "Manifest file set does not match package file set.")

    for relative, path in actual.items():
        item = expected[relative]
        require(path.stat().st_size == item["bytes"], f"Size mismatch: {relative}")
        require(sha256(path) == item["sha256"], f"SHA-256 mismatch: {relative}")

    findings: list[dict[str, str]] = []
    for relative, path in actual.items():
        if path.suffix.lower() not in TEXT_SUFFIXES:
            continue
        text = path.read_text(encoding="utf-8-sig", errors="replace")
        for label, pattern in FORBIDDEN.items():
            if pattern.search(text):
                findings.append({"path": relative, "category": label})
    require(not findings, "Anonymity/credential scan failed: " + json.dumps(findings))

    core = run_json(
        "code/verify_original_core.py",
        "data/original_core/qwen2.5-7b_a100_raw.json",
        "data/original_core/qwen2.5-7b_l4_raw.json",
    )
    analysis_7b = run_json("code/analyze_7b.py", "data/replication_7b")
    analysis_14b = run_json("code/analyze_12_14b.py", "data/replication_12_14b")
    require(core.get("state") == "pass", "Original core verifier did not pass.")
    require(
        analysis_7b.get("state") == "complete_and_independently_classified",
        "7B analysis did not complete.",
    )
    require(
        analysis_14b.get("state") == "complete_and_independently_classified",
        "12-14B analysis did not complete.",
    )
    require(
        analysis_14b.get("three_family_classification")
        == "strong_descriptive_replication",
        "Three-family classification drifted.",
    )
    return {
        "state": "pass",
        "manifest_files": len(actual),
        "manifest_bytes": sum(path.stat().st_size for path in actual.values()),
        "anonymity_findings": 0,
        "original_core": {
            "a100_negative": core["a100"]["negative"],
            "l4_negative": core["l4"]["negative"],
            "same_text_negative": core["a100"]["exact_same_text_negative"],
        },
        "replication_7b_models": len(analysis_7b["models"]),
        "replication_12_14b_models": len(analysis_14b["models"]),
        "three_family_classification": analysis_14b["three_family_classification"],
    }


def main() -> int:
    try:
        print(json.dumps(verify(), ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, KeyError, TypeError, PackageError) as exc:
        print(json.dumps({"state": "review_required", "error": str(exc)}, indent=2), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
