#!/usr/bin/env python3
"""Read-only independent analyzer for AI4GOOD replication raw artifacts.

Uses only the Python standard library. It never loads a model, accesses the
network, or modifies the input directory. JSON is written only when the caller
supplies a new --output path.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any


EXPECTED_RUNNER_SHA256 = (
    "e71bc1af627ca6487dbeb6b824f56594755b9de0f1fdefddaaf958a874e42145"
)
REFERENCE_QWEN_MEAN_SHIFT = -21.269761556990083
FACT_IDS = [
    "arithmetic",
    "ph_water",
    "australia_capital",
    "light_speed",
    "war_and_peace",
    "water_formula",
    "human_chromosomes",
]
EXPECTED_ORDERS = [
    [3, 4, 5, 6, 0, 1, 2],
    [6, 2, 0, 5, 3, 4, 1],
    [6, 1, 5, 2, 4, 0, 3],
]
EXPECTED_MODELS = [
    {
        "id": "Qwen/Qwen2.5-7B-Instruct",
        "revision": "a09a35458c702b33eeacc393d103063234e8bc28",
        "slug": "qwen2.5-7b-instruct",
        "family": "qwen2",
        "anchor": True,
    },
    {
        "id": "mistralai/Mistral-7B-Instruct-v0.3",
        "revision": "c170c708c41dac9275d15a8fff4eca08d52bab71",
        "slug": "mistral-7b-instruct-v0.3",
        "family": "mistral",
        "anchor": False,
    },
]


class ValidationError(RuntimeError):
    pass


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValidationError(message)


def directional_gate(
    negative_pairs: int,
    negative_clusters: int,
    median_pair: float,
    median_cluster: float,
) -> str:
    if (
        negative_pairs >= 80
        and negative_clusters >= 18
        and median_pair < 0
        and median_cluster < 0
    ):
        return "nominal_pass"
    if (
        negative_pairs >= 67
        and negative_clusters >= 16
        and median_pair < 0
        and median_cluster < 0
    ):
        return "tolerance_pass"
    if negative_clusters >= 11 and median_pair < 0 and median_cluster < 0:
        return "borderline_transition"
    return "out_of_tolerance_but_analyzable"


def expected_row_keys() -> set[tuple[int, int, str]]:
    keys: set[tuple[int, int, str]] = set()
    for repeat, order in enumerate(EXPECTED_ORDERS):
        for cascade_size in range(1, 8):
            for fact_index in order[:cascade_size]:
                keys.add((repeat, cascade_size, FACT_IDS[fact_index]))
    require(len(keys) == 84, "Internal expected design does not contain 84 rows.")
    return keys


def compare_summary(embedded: dict[str, Any], calculated: dict[str, Any]) -> None:
    exact_fields = [
        "pairs",
        "negative_pairs",
        "clusters",
        "negative_clusters",
        "directional_gate",
        "anchor_reproduction_gate",
        "exact_same_text_pairs",
        "exact_same_text_negative",
        "blind_spot_gate",
    ]
    numeric_fields = [
        "mean_shift",
        "median_shift",
        "minimum_shift",
        "maximum_shift",
        "median_cluster_mean",
        "anchor_mean_distance",
    ]
    for field in exact_fields:
        require(
            embedded.get(field) == calculated.get(field),
            f"Embedded summary mismatch for {field}.",
        )
    for field in numeric_fields:
        left = embedded.get(field)
        right = calculated.get(field)
        if left is None or right is None:
            require(left is right, f"Embedded summary mismatch for {field}.")
        else:
            require(
                math.isclose(float(left), float(right), rel_tol=0.0, abs_tol=1e-9),
                f"Embedded summary mismatch for {field}.",
            )


def analyze_model(document: dict[str, Any], expected_model: dict[str, Any]) -> dict[str, Any]:
    require(document.get("schema_version") == 1, "Raw schema_version is not 1.")
    require(document.get("state") == "complete", "Raw model state is not complete.")
    require(document.get("model") == expected_model, "Pinned model metadata drifted.")
    metadata = document.get("metadata")
    require(isinstance(metadata, dict), "Raw model metadata is absent.")
    require(metadata.get("dtype") == "bfloat16", "Run dtype is not bfloat16.")
    require(bool(metadata.get("gpu_name")), "GPU name is absent.")
    require(bool(metadata.get("cuda_version")), "CUDA version is absent.")

    rows = document.get("rows")
    require(isinstance(rows, list) and len(rows) == 84, "Raw rows are not exactly 84.")
    require(len({row.get("key") for row in rows}) == 84, "Raw row keys are not unique.")

    observed_design: set[tuple[int, int, str]] = set()
    shifts: list[float] = []
    clusters: dict[tuple[int, str], list[float]] = defaultdict(list)
    same_text_shifts: list[float] = []

    for row in rows:
        repeat = int(row["repeat"])
        cascade_size = int(row["cascade_size"])
        fact_id = str(row["fact_id"])
        require(0 <= repeat < 3, "Row repeat is outside 0..2.")
        require(1 <= cascade_size <= 7, "Row cascade_size is outside 1..7.")
        order = [int(value) for value in row["order"]]
        require(order == EXPECTED_ORDERS[repeat], "Row order drifted.")
        injected = [int(value) for value in row["injected_fact_indices"]]
        require(injected == order[:cascade_size], "Injected prefix drifted.")
        require(fact_id in FACT_IDS, "Unknown fact_id in raw row.")
        require(FACT_IDS.index(fact_id) in injected, "Row fact is not in injected prefix.")

        shift = float(row["shift"])
        require(math.isfinite(shift), "Non-finite shift in raw row.")
        compatible = float(row["compatible"]["contrast_total"])
        conflict = float(row["conflict"]["contrast_total"])
        require(
            math.isclose(shift, conflict - compatible, rel_tol=0.0, abs_tol=1e-9),
            "Stored shift does not equal conflict minus compatible contrast.",
        )
        exact_same_text = row["exact_same_text"]
        require(isinstance(exact_same_text, bool), "exact_same_text is not boolean.")

        observed_design.add((repeat, cascade_size, fact_id))
        shifts.append(shift)
        clusters[(repeat, fact_id)].append(shift)
        if exact_same_text:
            same_text_shifts.append(shift)

    require(observed_design == expected_row_keys(), "Observed 84-row design drifted.")
    require(len(clusters) == 21, "Observed cluster count is not 21.")
    cluster_means = [statistics.fmean(values) for values in clusters.values()]
    negative_pairs = sum(value < 0 for value in shifts)
    negative_clusters = sum(value < 0 for value in cluster_means)
    median_pair = float(statistics.median(shifts))
    median_cluster = float(statistics.median(cluster_means))
    gate = directional_gate(negative_pairs, negative_clusters, median_pair, median_cluster)

    if len(same_text_shifts) < 10:
        blind_spot_gate = "not_evaluable"
    elif all(value < 0 for value in same_text_shifts):
        blind_spot_gate = "nominal_pass"
    else:
        blind_spot_gate = "mixed"

    anchor_distance: float | None = None
    anchor_gate = "not_applicable"
    if expected_model["anchor"]:
        anchor_distance = abs(statistics.fmean(shifts) - REFERENCE_QWEN_MEAN_SHIFT)
        if gate == "nominal_pass" and anchor_distance <= 1.0:
            anchor_gate = "nominal_pass"
        elif gate in {"nominal_pass", "tolerance_pass"} and anchor_distance <= 2.0:
            anchor_gate = "tolerance_pass"
        else:
            anchor_gate = "not_reproduced"

    calculated = {
        "pairs": len(shifts),
        "negative_pairs": negative_pairs,
        "mean_shift": float(statistics.fmean(shifts)),
        "median_shift": median_pair,
        "minimum_shift": float(min(shifts)),
        "maximum_shift": float(max(shifts)),
        "clusters": len(cluster_means),
        "negative_clusters": negative_clusters,
        "median_cluster_mean": median_cluster,
        "directional_gate": gate,
        "anchor_mean_distance": anchor_distance,
        "anchor_reproduction_gate": anchor_gate,
        "exact_same_text_pairs": len(same_text_shifts),
        "exact_same_text_negative": sum(value < 0 for value in same_text_shifts),
        "blind_spot_gate": blind_spot_gate,
    }
    embedded = document.get("summary")
    require(isinstance(embedded, dict), "Embedded summary is absent.")
    compare_summary(embedded, calculated)
    return calculated


def analyze_directory(input_dir: Path) -> dict[str, Any]:
    require(input_dir.is_dir(), "Input path is not a directory.")
    manifest_path = input_dir / "design_manifest.json"
    require(manifest_path.is_file(), "design_manifest.json is absent.")
    manifest = load_json(manifest_path)
    require(manifest.get("schema_version") == 1, "Manifest schema_version is not 1.")
    require(manifest.get("models") == EXPECTED_MODELS, "Manifest model pins drifted.")
    require(manifest.get("orders") == EXPECTED_ORDERS, "Manifest orders drifted.")
    require(manifest.get("seed") == 20260716, "Manifest seed drifted.")
    manifest_facts = manifest.get("facts")
    require(
        isinstance(manifest_facts, list)
        and [fact.get("id") for fact in manifest_facts] == FACT_IDS,
        "Manifest fact identifiers or order drifted.",
    )
    require(manifest.get("script_sha256") == EXPECTED_RUNNER_SHA256, "Runner SHA-256 drifted.")
    require(manifest.get("no_quantized_fallback") is True, "Quantized fallback guard is absent.")
    require(manifest.get("no_paid_api") is True, "Paid API guard is absent.")

    if manifest.get("state") == "technical_failure":
        return {
            "schema_version": 1,
            "state": "technical_failure",
            "changed_inputs": False,
            "manifest_sha256": file_sha256(manifest_path),
            "error_type": manifest.get("error_type"),
            "error": manifest.get("error"),
            "permitted_interpretation": "Technical failure only; no behavioural claim.",
        }
    require(manifest.get("state") == "complete", "Manifest is neither complete nor technical_failure.")

    analyses: list[dict[str, Any]] = []
    raw_hashes: dict[str, str] = {}
    raw_summaries: list[dict[str, Any]] = []
    for model in EXPECTED_MODELS:
        raw_path = input_dir / f"{model['slug']}_raw.json"
        require(raw_path.is_file(), f"Missing raw file for {model['slug']}.")
        raw_document = load_json(raw_path)
        analysis = analyze_model(raw_document, model)
        analyses.append({"model": model, "analysis": analysis})
        raw_summaries.append(raw_document["summary"])
        raw_hashes[raw_path.name] = file_sha256(raw_path)

    combined_path = input_dir / "combined_summary.json"
    require(combined_path.is_file(), "combined_summary.json is absent.")
    combined = load_json(combined_path)
    require(combined.get("schema_version") == 1, "Combined schema_version is not 1.")
    require(combined.get("state") == "complete", "Combined state is not complete.")
    combined_models = combined.get("models")
    require(isinstance(combined_models, list) and len(combined_models) == 2, "Combined model count is not 2.")
    for index, model in enumerate(EXPECTED_MODELS):
        require(combined_models[index].get("model") == model, "Combined model metadata drifted.")
        require(combined_models[index].get("summary") == raw_summaries[index], "Combined summary differs from raw summary.")

    return {
        "schema_version": 1,
        "state": "complete_and_independently_classified",
        "changed_inputs": False,
        "manifest_sha256": file_sha256(manifest_path),
        "raw_sha256": raw_hashes,
        "combined_summary_sha256": file_sha256(combined_path),
        "models": analyses,
        "permitted_interpretation": (
            "Controlled descriptive per-model replication only. Preserve mixed, "
            "borderline and out-of-tolerance outcomes; no causal, energy, cost, "
            "deployment, universal-safety or social-impact claim."
        ),
    }


def synthetic_document(shift: float = -1.0) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for repeat, order in enumerate(EXPECTED_ORDERS):
        for cascade_size in range(1, 8):
            injected = order[:cascade_size]
            for fact_index in injected:
                fact_id = FACT_IDS[fact_index]
                rows.append(
                    {
                        "key": f"{repeat}|{cascade_size}|{fact_id}|" + ",".join(map(str, order)),
                        "repeat": repeat,
                        "cascade_size": cascade_size,
                        "order": order,
                        "injected_fact_indices": injected,
                        "fact_id": fact_id,
                        "shift": shift,
                        "compatible": {"contrast_total": 0.0},
                        "conflict": {"contrast_total": shift},
                        "exact_same_text": True,
                    }
                )
    cluster_means = [shift] * 21
    summary = {
        "pairs": 84,
        "negative_pairs": 84 if shift < 0 else 0,
        "mean_shift": shift,
        "median_shift": shift,
        "minimum_shift": shift,
        "maximum_shift": shift,
        "clusters": 21,
        "negative_clusters": 21 if shift < 0 else 0,
        "median_cluster_mean": statistics.median(cluster_means),
        "directional_gate": directional_gate(
            84 if shift < 0 else 0, 21 if shift < 0 else 0, shift, shift
        ),
        "anchor_mean_distance": abs(shift - REFERENCE_QWEN_MEAN_SHIFT),
        "anchor_reproduction_gate": "not_reproduced",
        "exact_same_text_pairs": 84,
        "exact_same_text_negative": 84 if shift < 0 else 0,
        "blind_spot_gate": "nominal_pass" if shift < 0 else "mixed",
    }
    return {
        "schema_version": 1,
        "state": "complete",
        "model": EXPECTED_MODELS[0],
        "metadata": {"dtype": "bfloat16", "gpu_name": "synthetic", "cuda_version": "synthetic"},
        "rows": rows,
        "summary": summary,
    }


def self_test() -> dict[str, Any]:
    gates = {
        "nominal": directional_gate(80, 18, -1.0, -1.0),
        "tolerance": directional_gate(67, 16, -1.0, -1.0),
        "borderline": directional_gate(60, 11, -1.0, -1.0),
        "outside": directional_gate(40, 10, 1.0, 1.0),
    }
    require(
        gates
        == {
            "nominal": "nominal_pass",
            "tolerance": "tolerance_pass",
            "borderline": "borderline_transition",
            "outside": "out_of_tolerance_but_analyzable",
        },
        "Directional gate self-test failed.",
    )
    calculated = analyze_model(synthetic_document(), EXPECTED_MODELS[0])
    malformed = synthetic_document()
    malformed["rows"][1]["key"] = malformed["rows"][0]["key"]
    rejected_duplicate = False
    try:
        analyze_model(malformed, EXPECTED_MODELS[0])
    except ValidationError:
        rejected_duplicate = True
    require(rejected_duplicate, "Malformed duplicate-key artifact was not rejected.")
    return {
        "state": "self_test_pass",
        "gates": gates,
        "synthetic_pairs": calculated["pairs"],
        "synthetic_clusters": calculated["clusters"],
        "malformed_duplicate_rejected": rejected_duplicate,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_dir", nargs="?", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()

    try:
        if args.self_test:
            result = self_test()
        else:
            require(args.input_dir is not None, "input_dir is required.")
            result = analyze_directory(args.input_dir)
        rendered = json.dumps(result, ensure_ascii=False, indent=2)
        if args.output is not None:
            require(not args.output.exists(), "Refusing to overwrite --output.")
            args.output.write_text(rendered + "\n", encoding="utf-8")
        print(rendered)
        return 0
    except (ValidationError, OSError, ValueError, KeyError, TypeError) as exc:
        print(
            json.dumps(
                {"state": "review_required", "error_type": type(exc).__name__, "error": str(exc)},
                ensure_ascii=False,
                indent=2,
            ),
            file=sys.stderr,
        )
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
