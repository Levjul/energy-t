#!/usr/bin/env python3
"""Verify the original Qwen2.5-7B A100/L4 paired result from raw JSON."""

from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any


EXPECTED = {
    "a100_mean": -21.269761556990083,
    "l4_mean": -21.3193402180488,
    "correlation": 0.998995967954884,
}


class VerificationError(RuntimeError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise VerificationError(message)


def load_pairs(path: Path) -> list[dict[str, Any]]:
    document = json.loads(path.read_text(encoding="utf-8"))
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in document["runs"]:
        if row["condition"] == "BASELINE":
            continue
        key = "|".join(
            [
                str(row["repeat"]),
                str(row["cascade_size"]),
                str(row["fact_id"]),
                ",".join(str(value) for value in row["order"]),
            ]
        )
        groups[key].append(row)

    paired: list[dict[str, Any]] = []
    for key, rows in groups.items():
        compatible = [row for row in rows if row["condition"] == "COMPATIBLE"]
        conflict = [row for row in rows if row["condition"] == "CONFLICT"]
        require(len(compatible) == 1 and len(conflict) == 1, f"Pairing failed: {key}")
        left, right = compatible[0], conflict[0]
        paired.append(
            {
                "key": key,
                "compatible_contrast": float(left["contrast_total"]),
                "conflict_contrast": float(right["contrast_total"]),
                "shift": float(right["contrast_total"]) - float(left["contrast_total"]),
                "compatible_class": left["trajectory"]["response_class"],
                "conflict_class": right["trajectory"]["response_class"],
                "exact_same_text": left["trajectory"]["response_text"]
                == right["trajectory"]["response_text"],
            }
        )
    return sorted(paired, key=lambda row: row["key"])


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    shifts = [row["shift"] for row in rows]
    both_target = [
        row
        for row in rows
        if row["compatible_class"] == "TARGET" and row["conflict_class"] == "TARGET"
    ]
    same_text = [row for row in rows if row["exact_same_text"]]
    return {
        "pairs": len(rows),
        "negative": sum(row["shift"] < 0 for row in rows),
        "zero": sum(row["shift"] == 0 for row in rows),
        "positive": sum(row["shift"] > 0 for row in rows),
        "mean_shift": statistics.mean(shifts),
        "median_shift": statistics.median(shifts),
        "minimum_shift": min(shifts),
        "maximum_shift": max(shifts),
        "both_target_pairs": len(both_target),
        "both_target_negative": sum(row["shift"] < 0 for row in both_target),
        "both_target_mean_shift": statistics.mean(row["shift"] for row in both_target),
        "exact_same_text_pairs": len(same_text),
        "exact_same_text_negative": sum(row["shift"] < 0 for row in same_text),
        "exact_same_text_mean_shift": statistics.mean(row["shift"] for row in same_text),
        "exact_same_text_minimum_shift": min(row["shift"] for row in same_text),
        "exact_same_text_maximum_shift": max(row["shift"] for row in same_text),
    }


def pearson(x: list[float], y: list[float]) -> float:
    require(len(x) == len(y) and len(x) >= 2, "Correlation vectors do not align.")
    mean_x, mean_y = statistics.mean(x), statistics.mean(y)
    dx = [value - mean_x for value in x]
    dy = [value - mean_y for value in y]
    numerator = sum(a * b for a, b in zip(dx, dy))
    denominator = math.sqrt(sum(a * a for a in dx) * sum(b * b for b in dy))
    return numerator / denominator


def verify(a100_path: Path, l4_path: Path) -> dict[str, Any]:
    a100 = load_pairs(a100_path)
    l4 = load_pairs(l4_path)
    require([row["key"] for row in a100] == [row["key"] for row in l4], "Pair keys differ.")
    a100_summary, l4_summary = summarize(a100), summarize(l4)
    correlation = pearson([row["shift"] for row in a100], [row["shift"] for row in l4])

    require(a100_summary["pairs"] == 84 and a100_summary["negative"] == 84, "A100 gate failed.")
    require(l4_summary["pairs"] == 84 and l4_summary["negative"] == 84, "L4 gate failed.")
    require(a100_summary["exact_same_text_pairs"] == 25, "A100 same-text count drifted.")
    require(a100_summary["exact_same_text_negative"] == 25, "A100 same-text gate failed.")
    require(abs(a100_summary["mean_shift"] - EXPECTED["a100_mean"]) < 1e-12, "A100 mean drifted.")
    require(abs(l4_summary["mean_shift"] - EXPECTED["l4_mean"]) < 1e-12, "L4 mean drifted.")
    require(abs(correlation - EXPECTED["correlation"]) < 1e-12, "Correlation drifted.")
    return {
        "state": "pass",
        "a100": a100_summary,
        "l4": l4_summary,
        "a100_l4_shift_correlation": correlation,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("a100", type=Path)
    parser.add_argument("l4", type=Path)
    args = parser.parse_args()
    try:
        print(json.dumps(verify(args.a100, args.l4), ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError, KeyError, TypeError, VerificationError) as exc:
        print(json.dumps({"state": "review_required", "error": str(exc)}, indent=2), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
