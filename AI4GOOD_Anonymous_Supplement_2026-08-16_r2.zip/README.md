# Anonymous reproducibility supplement

This is the local, anonymous working supplement for the paper **Correct Answers
Can Hide Context-Induced Preference Shifts Across Open-Weight Model Families**.
It has not been uploaded, published, or submitted.

## Contents

- `code/`: two frozen Colab runners, two network-free replication analyzers,
  an independent verifier for the original A100/L4 core, and a whole-package
  verifier.
- `data/original_core/`: the original Qwen2.5-7B A100 and L4 raw JSON files.
- `data/replication_7b/`: the frozen design, both 7B raw JSON files, combined
  summary, and independent analysis.
- `data/replication_12_14b/`: the frozen design, three 12--14B raw JSON files,
  combined summary, and both Colab and local independent analyses.
- `protocol/`: preregistrations and the resource-only cache amendment.
- `MODEL_LICENSES.md`: exact checkpoint owners, revisions, upstream licenses,
  and primary model-card links.
- `MANIFEST.json`: path, role, byte size, and SHA-256 for every packaged file
  other than the manifest itself.

No model weights are redistributed. The facts and prompt templates are
synthetic. The package contains no participant data or human-subject data.

## Verify without a GPU or network

From the package root:

```text
python code/verify_package.py
```

The verifier checks the manifest, rejects unlisted files, scans text artifacts
for local paths, email addresses, and common credential patterns, re-computes
the original A100/L4 statistics, and re-runs both replication analyzers.

The expected terminal state is:

```text
"state": "pass"
```

## Re-run the model experiments

Use a CUDA Colab runtime with sufficient VRAM. Install:

```text
pip install -r requirements-colab.txt
```

Then run one frozen runner at a time:

```text
python code/runner_7b.py
python code/runner_12_14b.py
```

The 7B experiment used an NVIDIA A100-SXM4-40GB. The larger experiment runs
the three checkpoints sequentially on an A100 and deliberately deletes only
its temporary Hugging Face cache between completed models after verifying the
raw result file. Runners never call a paid inference API and do not upload or
submit their outputs.

## Interpretation boundary

The package supports a controlled descriptive result for five exact model
variants under one seven-fact, three-order, cumulative-context protocol. It
does not establish a causal mechanism, scaling law, physical-energy result,
deployment behavior, universal safety property, or social-impact outcome.

## Release status

This working supplement documents upstream model licenses but does not grant a
new public license for the newly packaged code or raw artifacts. A publication
license and the final anonymous OpenReview upload remain separate author
decisions.
