"""Offline integrity checks and reproduction of the existing A2/C analyses."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import zipfile

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'MANIFEST.json').read_text(encoding='utf-8'))
for item in manifest['files']:
    path = (root / item['path']).resolve()
    assert path.is_relative_to(root), item['path']
    data = path.read_bytes()
    assert len(data) == item['bytes'], item['path']
    assert hashlib.sha256(data).hexdigest() == item['sha256'], item['path']
    if path.suffix == '.zip':
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None, item['path']

env = dict(os.environ, PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1')
with tempfile.TemporaryDirectory(prefix='verify_', dir=root) as tmp:
    subprocess.run([sys.executable, '-B', str(root/'analysis/A2/a2_analyze.py'),
                    '--root', str(root/'inputs/A2'), '--out', 'a2.json'],
                   cwd=tmp, env=env, check=True, stdout=subprocess.PIPE)
    got = json.loads((Path(tmp)/'a2.json').read_bytes())
    assert got == json.loads((root/'analysis/A2/a2_raw.json').read_bytes())
    subprocess.run([sys.executable, '-B', str(root/'analysis/C/recount_expC.py'),
                    str(root/'inputs/ecdl_dataset_v2.csv')],
                   cwd=tmp, env=env, check=True, stdout=subprocess.PIPE)
    got = json.loads((Path(tmp)/'expC_recount.json').read_bytes())
    expected = json.loads((root/'verification/expC_recount.json').read_bytes())
    assert {k:v for k,v in got.items() if k != 'source'} == {
        k:v for k,v in expected.items() if k != 'source'}
print(f'PASS: {len(manifest["files"])} file hashes; ZIP CRCs; A2/C offline reproduction.')
