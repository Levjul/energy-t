# -*- coding: utf-8 -*-
"""E4 — цепочки зависящих шагов. Заморожено вместе со спекой.

Каждый экземпляр: корневая величина + цепочка операций, где КАЖДЫЙ шаг
вычисляется из предыдущего. Ложь в корне делает ложными все производные узлы,
причём производные значения в тексте коррекции НЕ называются. Коррекция
исправляет только корень. Модель обязана пересчитать цепочку сама.

Это отличие от Э2: там подкрепления ПОВТОРЯЛИ одно утверждение, здесь шаги
ЗАВИСЯТ от него.
"""
ENTITIES = [
    "batch Q7", "lot M3", "shipment K9", "series B4", "run T2",
    "tray L8", "crate D5", "pallet R1", "unit V6", "case N4",
    "sample P2", "block G7", "reel H3", "spool W5", "bin Z8",
    "rack C6", "tube J1", "frame Y9", "panel X4", "coil F2",
]
OPS = [("doubled", 2, 0), ("increased by 3", 1, 3),
       ("doubled", 2, 0), ("increased by 5", 1, 5)]
NODE = ["P", "R", "S", "T"]
BASES = [2, 3, 4, 5]          # истинное корневое значение
FALSE_OFFSET = 2               # ложное = истинное + 2 (цепочки не пересекаются)


def chain(base):
    """Возвращает список значений узлов P,R,S,T."""
    v, out = base, []
    for mul, add in [(o[1], o[2]) for o in OPS]:
        v = v * mul + add
        out.append(v)
    return out


def op_text(j, base_label="the base count"):
    name, mul, add = OPS[j]
    prev = base_label if j == 0 else "value " + NODE[j - 1]
    if mul == 2:
        return "value %s = 2 x %s" % (NODE[j], prev)
    return "value %s = %s + %d" % (NODE[j], prev, add)


INSTANCES = []
for i, ent in enumerate(ENTITIES):
    b = BASES[i % len(BASES)]
    INSTANCES.append({
        "id": "%s_b%d" % (ent.replace(" ", ""), b),
        "entity": ent,
        "base_true": b,
        "base_false": b + FALSE_OFFSET,
        "true_chain": chain(b),
        "false_chain": chain(b + FALSE_OFFSET),
    })

# ни одно истинное значение узла не должно совпасть с ложным на том же узле
for ins in INSTANCES:
    for a, c in zip(ins["true_chain"], ins["false_chain"]):
        assert a != c, ins["id"]
assert len({i["id"] for i in INSTANCES}) == len(INSTANCES)
