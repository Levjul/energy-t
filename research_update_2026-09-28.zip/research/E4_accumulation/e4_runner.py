#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E4 — Накопление: растёт ли остаточный дефицит с числом ЗАВИСЯЩИХ шагов.
Преджистрация: E4_SPEC_PREREG_2026-08-27.md v0.1. Заморожена до прогона.

Отличие от Э2: там k подкреплений ПОВТОРЯЛИ одно и то же утверждение (роста не
нашлось). Здесь d шагов ЗАВИСЯТ от корня: ложь в корне делает ложными все
производные значения, а коррекция исправляет ТОЛЬКО корень и производных
значений не называет. Модель обязана пересчитать цепочку сама.

Ветки: base / mention / name. Только teacher forcing. Генерации нет.
  python e4_runner.py --selftest
  python e4_runner.py --stub accum|noaccum --out DIR
  python e4_runner.py --out DIR
"""
import argparse, hashlib, json, os, sys, time
from e4_chains import INSTANCES, OPS, NODE, op_text

SPEC_VERSION = "E4_v0.1_2026-08-27"
MODEL_ID = "Qwen/Qwen2.5-7B-Instruct"
MODEL_REV = "a09a35458c702b33eeacc393d103063234e8bc28"
D_GRID = [0, 1, 2, 4]          # число зависящих шагов
R_GRID = [0, 1]                # коррекция корня
SEEDS = [1, 2, 3, 4, 5]
ARMS = ["base", "mention", "name"]

SYSTEM_MSG = "The following working notes were collected in order."
NAME_TPL = [
    "Correction: the earlier note stating that the base count of {ent} is {bad} is wrong. The base count of {ent} is {good}.",
    "An audit found an error above: the base count of {ent} is not {bad}; the correct base count is {good}.",
    "Please disregard the previous claim that the base count of {ent} is {bad}. The verified base count of {ent} is {good}.",
]
CONFIRM_TPL = [
    "Confirmation: the earlier note stating that the base count of {ent} is {good} is correct. The base count of {ent} is {good}.",
    "An audit reviewed the note above: the base count of {ent} is indeed {good}; the recorded base count is {good}.",
    "Please retain the previous note stating that the base count of {ent} is {good}. The verified base count of {ent} is {good}.",
]
CORRECTION_MARKERS = ("Correction:", "An audit", "Please disregard",
                      "Confirmation:", "Please retain")


def build_context(ii, d, r, seed, arm):
    ins = INSTANCES[ii]
    ent = ins["entity"]
    truthful = arm in ("base", "mention")
    base_v = ins["base_true"] if truthful else ins["base_false"]
    ch = ins["true_chain"] if truthful else ins["false_chain"]
    notes = ["The base count of %s is %d." % (ent, base_v)]
    for j in range(d):
        notes.append("Step %d: %s = %d." % (j + 1, op_text(j), ch[j]))
    if r:
        tpls = CONFIRM_TPL if arm == "base" else NAME_TPL
        for q in range(r):
            notes.append(tpls[(q + seed) % len(tpls)].format(
                ent=ent, bad=ins["base_false"], good=ins["base_true"]))
    if d == 0:
        question = "What is the base count of %s?" % ent
        t_ans, f_ans = str(ins["base_true"]), str(ins["base_false"])
    else:
        question = "What is value %s?" % NODE[d - 1]
        t_ans, f_ans = str(ins["true_chain"][d - 1]), str(ins["false_chain"][d - 1])
    body = "\n".join("Note %d: %s" % (i + 1, s) for i, s in enumerate(notes))
    user = body + "\n\nQuestion: " + question + " Answer with the number only."
    return ([{"role": "system", "content": SYSTEM_MSG},
             {"role": "user", "content": user}],
            {"n_notes": len(notes), "ctx_chars": len(user),
             "t_ans": t_ans, "f_ans": f_ans})


class StubScorer:
    """Видит только контекст. accum — дефицит растёт с числом зависящих шагов."""
    def __init__(self, scenario):
        self.scenario = scenario

    def margins(self, messages, meta, cell):
        ii = cell[0]
        ins = INSTANCES[ii]
        text = messages[1]["content"]
        lines = [l.split(": ", 1)[1] if ": " in l else l
                 for l in text.split("\n") if l.startswith("Note ")]
        asserts = [l for l in lines if not l.startswith(CORRECTION_MARKERS)]
        corrs = [l for l in lines if l.startswith(CORRECTION_MARKERS)]
        bad = str(ins["base_false"])
        believed = any(("is %s." % bad) in l for l in asserts)
        names_false = any(bad in l for l in corrs)
        repaired = bool(corrs)
        nsteps = sum(1 for l in asserts if l.startswith("Step"))
        h = int(hashlib.sha256(text.encode()).hexdigest()[:8], 16)
        m = -0.5 + ((h % 1000) / 1000.0 - 0.5) * 0.4
        if believed and not repaired:
            m -= 30.0
        if names_false:
            m -= 3.0
        if believed and repaired:
            m -= 1.5 + (0.9 * nsteps if self.scenario == "accum" else 0.0)
        return -20.0 + m, -20.0, True, 2, 2


class HFScorer:
    def __init__(self):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.torch = torch
        self.tok = AutoTokenizer.from_pretrained(MODEL_ID, revision=MODEL_REV)
        self.model = AutoModelForCausalLM.from_pretrained(
            MODEL_ID, revision=MODEL_REV, torch_dtype=torch.bfloat16, device_map="auto")
        self.model.eval()

    def margins(self, messages, meta, cell):
        torch = self.torch
        prompt = self.tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        ids_p = self.tok(prompt, add_special_tokens=False)["input_ids"]
        outs, oks, ns = [], [], []
        for ans in (meta["t_ans"], meta["f_ans"]):
            ids_f = self.tok(prompt + ans, add_special_tokens=False)["input_ids"]
            ok = ids_f[:len(ids_p)] == ids_p
            if not ok:
                ids_f = ids_p + self.tok(ans, add_special_tokens=False)["input_ids"]
            with torch.no_grad():
                t = torch.tensor([ids_f], device=self.model.device)
                lp = torch.log_softmax(self.model(t).logits[0].float(), dim=-1)
            outs.append(sum(float(lp[i - 1, ids_f[i]]) for i in range(len(ids_p), len(ids_f))))
            oks.append(ok); ns.append(len(ids_f) - len(ids_p))
        return outs[0], outs[1], (oks[0] and oks[1]), ns[0], ns[1]


def run(scorer, out_dir, name):
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, "runs.jsonl")
    total = len(INSTANCES) * len(D_GRID) * len(R_GRID) * len(SEEDS) * len(ARMS)
    n, t0 = 0, time.time()
    with open(path, "w", encoding="utf-8") as fh:
        for ii in range(len(INSTANCES)):
            for d in D_GRID:
                for r in R_GRID:
                    for s in SEEDS:
                        for arm in ARMS:
                            cell = (ii, d, r, s, arm)
                            msgs, meta = build_context(ii, d, r, s, arm)
                            sha = hashlib.sha256(json.dumps(msgs, ensure_ascii=False).encode()).hexdigest()
                            try:
                                lc, lf, pok, n1, n2 = scorer.margins(msgs, meta, cell)
                                ok = lc is not None and lf is not None and lc == lc and lf == lf
                            except Exception:
                                lc = lf = None; pok, n1, n2, ok = False, 0, 0, False
                            fh.write(json.dumps({
                                "inst": INSTANCES[ii]["id"], "inst_idx": ii, "d": d, "r": r,
                                "seed": s, "arm": arm, "lp_correct": lc, "lp_false": lf,
                                "margin": (lc - lf) if ok else None, "prefix_ok": bool(pok),
                                "n_ans_tokens": [n1, n2], "n_notes": meta["n_notes"],
                                "ctx_chars": meta["ctx_chars"], "ctx_sha256": sha,
                                "technical_failure": (not ok)}, ensure_ascii=False) + "\n")
                            n += 1
                            if n % 400 == 0:
                                el = time.time() - t0
                                print("  %d/%d %.0f%%  %.1f мин, осталось ~%.1f мин"
                                      % (n, total, 100.0*n/total, el/60, (el/n*(total-n))/60), flush=True)
    man = {"spec": SPEC_VERSION, "model": MODEL_ID, "revision": MODEL_REV, "scorer": name,
           "d_grid": D_GRID, "r_grid": R_GRID, "seeds": SEEDS, "arms": ARMS,
           "n_instances": len(INSTANCES), "n_rows": n,
           "runner_sha256": hashlib.sha256(open(os.path.abspath(__file__), "rb").read()).hexdigest(),
           "chains_sha256": hashlib.sha256(open(os.path.join(
               os.path.dirname(os.path.abspath(__file__)), "e4_chains.py"), "rb").read()).hexdigest(),
           "no_generation": True, "teacher_forcing_only": True,
           "elapsed_sec": round(time.time()-t0, 1),
           "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t0))}
    if name == "hf":
        try:
            import torch, transformers  # noqa
            man.update({"torch": torch.__version__, "transformers": transformers.__version__,
                        "cuda_device": torch.cuda.get_device_name(0), "dtype": "bfloat16"})
        except Exception:
            pass
    json.dump(man, open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    print("rows:", n, "->", path, "за %.1f мин" % ((time.time()-t0)/60))
    return path


def selftest():
    import tempfile, e4_analyze as A
    ok_all = True
    for scen, exp in (("accum", True), ("noaccum", False)):
        d = tempfile.mkdtemp(prefix="e4_%s_" % scen)
        run(StubScorer(scen), d, "stub-" + scen)
        res = A.analyze(os.path.join(d, "runs.jsonl"))
        g = res["gates"]
        ok = g["identity_pass"] and g["injection_pass"] and g["accum_pass"] == exp
        ok_all = ok_all and ok
        print("[selftest %s] identity=%s injection=%s accum=%s (ждали %s) -> %s"
              % (scen, g["identity_pass"], g["injection_pass"], g["accum_pass"], exp,
                 "PASS" if ok else "FAIL"))
        p = res["primary"]
        print("   A = Δ(d=4)-Δ(d=0) = %+.3f  CI95 [%+.3f, %+.3f]  neg %d/%d | %s"
              % (p["accum_mean"], p["accum_ci95"][0], p["accum_ci95"][1],
                 p["accum_neg"], p["accum_n"], res["verdict"]))
    print("SELFTEST:", "PASS" if ok_all else "FAIL")
    return 0 if ok_all else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--stub", choices=["accum", "noaccum"])
    ap.add_argument("--out", default="e4_out")
    a = ap.parse_args()
    if a.selftest:
        sys.exit(selftest())
    run(StubScorer(a.stub) if a.stub else HFScorer(), a.out,
        ("stub-" + a.stub) if a.stub else "hf")


if __name__ == "__main__":
    main()
