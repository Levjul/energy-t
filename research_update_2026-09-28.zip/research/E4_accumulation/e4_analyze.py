#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""E4 — независимый анализатор. Читает только runs.jsonl.
Гейты заморожены в E4_SPEC_PREREG_2026-08-27.md."""
import json, math, statistics, sys

BOOT_N, BOOT_SEED = 5000, 20260827


def binom_two_sided(n, k):
    pmf = lambda i: math.comb(n, i) * 0.5 ** n
    p = pmf(k)
    return min(1.0, sum(pmf(i) for i in range(n + 1) if pmf(i) <= p + 1e-15))


def boot_ci(v, n_boot=BOOT_N, seed=BOOT_SEED):
    if not v:
        return (None, None)
    st, m, out = seed & 0xFFFFFFFF, len(v), []
    for _ in range(n_boot):
        s = 0.0
        for _ in range(m):
            st = (1103515245 * st + 12345) & 0x7FFFFFFF
            s += v[st % m]
        out.append(s / m)
    out.sort()
    return (round(out[int(.025 * n_boot)], 4), round(out[int(.975 * n_boot) - 1], 4))


def analyze(path):
    rows = [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]
    tech = sum(1 for r in rows if r["technical_failure"])
    pref = sum(1 for r in rows if not r["prefix_ok"])
    R = {(r["inst"], r["d"], r["r"], r["seed"], r["arm"]): r
         for r in rows if not r["technical_failure"]}
    insts = sorted({k[0] for k in R})
    ds = sorted({k[1] for k in R})
    seeds = sorted({k[3] for k in R})
    M = lambda i, d, r, s, a: (R.get((i, d, r, s, a)) or {}).get("margin")

    # тождество при r=0: base и mention строят один и тот же контекст
    idc = idf = 0
    for i in insts:
        for d in ds:
            for s in seeds:
                a, b = R.get((i, d, 0, s, "mention")), R.get((i, d, 0, s, "base"))
                if a and b:
                    idc += 1
                    if a["ctx_sha256"] != b["ctx_sha256"] or a["margin"] != b["margin"]:
                        idf += 1
    identity_pass = idc > 0 and idf == 0

    inj = [M(i, d, 0, s, "name") - M(i, d, 0, s, "base")
           for i in insts for d in ds for s in seeds
           if M(i, d, 0, s, "name") is not None and M(i, d, 0, s, "base") is not None]
    inj_neg = sum(1 for v in inj if v < 0)
    injection_pass = len(inj) > 0 and inj_neg >= 0.85 * len(inj)

    def debt(i, d, s):
        a, b = M(i, d, 1, s, "name"), M(i, d, 1, s, "mention")
        return None if a is None or b is None else a - b

    by_d = {}
    for d in ds:
        v = [debt(i, d, s) for i in insts for s in seeds if debt(i, d, s) is not None]
        by_d[str(d)] = {"mean": round(statistics.mean(v), 4), "n": len(v),
                        "neg": sum(1 for x in v if x < 0), "ci95": boot_ci(v)}

    # первичная: A = Δ(d=max) - Δ(d=0), кластер = (инстанс, сид)
    dmax = max(ds)
    A = [debt(i, dmax, s) - debt(i, 0, s) for i in insts for s in seeds
         if debt(i, dmax, s) is not None and debt(i, 0, s) is not None]
    a_ci = boot_ci(A)
    a_neg = sum(1 for v in A if v < 0)
    accum_pass = bool(identity_pass and injection_pass and a_ci[1] is not None
                      and a_ci[1] < 0 and a_neg >= 0.65 * len(A))

    verdict = ("НАКОПЛЕНИЕ ЕСТЬ: дефицит растёт с числом зависящих шагов"
               if accum_pass else
               "накопления нет: дефицит не растёт с числом зависящих шагов")

    inj_by_d = {str(d): round(statistics.mean(
        [M(i, d, 0, s, "name") - M(i, d, 0, s, "base") for i in insts for s in seeds]), 4)
        for d in ds}
    resid_by_d = {str(d): round(statistics.mean(
        [M(i, d, 1, s, "name") - M(i, d, 1, s, "base") for i in insts for s in seeds]), 4)
        for d in ds}

    return {"n_rows": len(rows), "technical_failures": tech, "prefix_fallback_rows": pref,
            "gates": {"identity_pass": identity_pass, "identity_checked": idc,
                      "identity_failed": idf, "injection_pass": bool(injection_pass),
                      "injection_neg": "%d/%d" % (inj_neg, len(inj)),
                      "injection_mean": round(statistics.mean(inj), 4) if inj else None,
                      "accum_pass": accum_pass},
            "primary": {"accum_mean": round(statistics.mean(A), 4), "accum_n": len(A),
                        "accum_neg": a_neg, "accum_ci95": a_ci,
                        "accum_p": binom_two_sided(len(A), len(A) - a_neg),
                        "accum_median": round(statistics.median(A), 4)},
            "debt_by_depth": by_d,
            "injection_by_depth": inj_by_d,
            "residual_total_by_depth": resid_by_d,
            "verdict": verdict}


if __name__ == "__main__":
    p = sys.argv[1] if len(sys.argv) > 1 else "e4_out/runs.jsonl"
    res = analyze(p)
    json.dump(res, open(p.rsplit("/", 1)[0] + "/analysis.json", "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    print(json.dumps(res, ensure_ascii=False, indent=1))
