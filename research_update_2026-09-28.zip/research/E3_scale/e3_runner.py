#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E3 — масштабирование Э2b: 40 фактов, 5 сидов, две независимые семьи формулировок.
Преджистрация: E3_SPEC_PREREG_2026-08-27.md (v0.1). Заморожена до прогона.

Ветки те же, что в Э2b: base / mention / name / silent.
Только teacher forcing двух заранее заданных последовательностей.
Генерации нет, парсинга сгенерированного текста нет.

  python e3_runner.py --selftest
  python e3_runner.py --stub debt|nodebt --out DIR
  python e3_runner.py --out DIR
"""
import argparse, hashlib, json, os, sys, time

from e3_facts import FACTS

SPEC_VERSION = "E3_v0.1_2026-08-27"
MODEL_ID = "Qwen/Qwen2.5-7B-Instruct"
MODEL_REV = "a09a35458c702b33eeacc393d103063234e8bc28"
K_GRID = [0, 4]
R_GRID = [0, 1, 2]
SEEDS = [1, 2, 3, 4, 5]
ARMS = ["base", "mention", "name", "silent"]
FAMILIES = ["A", "B"]

REINFORCE = {
    "A": ["As recorded above, {subj} is {v}.",
          "Later notes rely on the fact that {subj} is {v}.",
          "For all following work, {subj} is taken to be {v}.",
          "It has been double-checked that {subj} is {v}."],
    "B": ["The register confirms once more: {subj} is {v}.",
          "Downstream entries assume throughout that {subj} is {v}.",
          "Carried forward without change: {subj} is {v}.",
          "Cross-referenced and kept: {subj} is {v}."],
}
NAME_TPL = {  # называет ложное значение
    "A": ["Correction: the earlier notes stating that {subj} is {bad} are wrong. In fact, {subj} is {good}.",
          "An audit found an error above: {subj} is not {bad}; the correct value is {good}.",
          "Please disregard previous claims that {subj} is {bad}. The verified value: {subj} is {good}.",
          "Final erratum: every statement above giving {bad} for {subj} is invalid; {subj} is {good}."],
    "B": ["Revision notice: where the notes above give {bad} for {subj}, that entry is void; {subj} is {good}.",
          "The reviewer rejected {bad} as the value of {subj}. The value on record is {good}.",
          "Strike the value {bad} for {subj} from the notes above. {subj} is {good}.",
          "Amendment: {subj} was misrecorded as {bad}. The established value is {good}."],
}
SILENT_TPL = {  # не называет ложное значение
    "A": ["Correction: the earlier notes about {subj} are wrong. In fact, {subj} is {good}.",
          "An audit found an error above concerning {subj}; the correct value is {good}.",
          "Please disregard previous claims about {subj}. The verified value: {subj} is {good}.",
          "Final erratum: every statement above about {subj} is invalid; {subj} is {good}."],
    "B": ["Revision notice: the entries above for {subj} are void; {subj} is {good}.",
          "The reviewer rejected the recorded value of {subj}. The value on record is {good}.",
          "Strike the earlier value of {subj} from the notes above. {subj} is {good}.",
          "Amendment: {subj} was misrecorded above. The established value is {good}."],
}
CONFIRM_TPL = {  # подтверждает истину, ложь не называет
    "A": ["Confirmation: the earlier notes stating that {subj} is {good} are correct. Indeed, {subj} is {good}.",
          "An audit reviewed the notes above: {subj} is indeed {good}; the recorded value is {good}.",
          "Please retain the previous notes stating that {subj} is {good}. The verified value: {subj} is {good}.",
          "Final review: every statement above giving {good} for {subj} is valid; {subj} is {good}."],
    "B": ["Revision notice: where the notes above give {good} for {subj}, that entry stands; {subj} is {good}.",
          "The reviewer accepted {good} as the value of {subj}. The value on record is {good}.",
          "Keep the value {good} for {subj} in the notes above. {subj} is {good}.",
          "Amendment: {subj} was recorded as {good}. The established value is {good}."],
}
SYSTEM_MSG = "The following working notes were collected in order."
STMT = "{subj} is {v}."

ARM_CFG = {"base": ("true", CONFIRM_TPL), "mention": ("true", NAME_TPL),
           "name": ("false", NAME_TPL), "silent": ("false", SILENT_TPL)}
CORRECTION_MARKERS = ("Correction:", "An audit", "Please disregard", "Final erratum",
                      "Confirmation:", "Please retain", "Final review",
                      "Revision notice:", "The reviewer", "Strike", "Keep the value",
                      "Amendment:")


def cap(s):
    return s[0].upper() + s[1:]


def build_context(fi, k, r, seed, arm, fam):
    f = FACTS[fi]
    truthness, tpls = ARM_CFG[arm]
    v_inj = f["true"] if truthness == "true" else f["false"]
    n = len(FACTS)
    pads = []
    step = 1
    while len(pads) < 2:
        j = (fi + seed * 7 + step * 13) % n
        if j != fi and j not in pads:
            pads.append(j)
        step += 1
    notes = [cap(STMT.format(subj=FACTS[j]["subj"], v=FACTS[j]["true"])) for j in pads]
    notes.append(cap(STMT.format(subj=f["subj"], v=v_inj)))
    rein = REINFORCE[fam]
    for j in range(k):
        notes.append(cap(rein[(j + seed) % len(rein)].format(subj=f["subj"], v=v_inj)))
    fam_tpls = tpls[fam]
    for j in range(r):
        notes.append(fam_tpls[(j + seed) % len(fam_tpls)].format(
            subj=f["subj"], bad=f["false"], good=f["true"]))
    body = "\n".join("Note %d: %s" % (i + 1, s) for i, s in enumerate(notes))
    user = body + "\n\nQuestion: " + f["q"] + " Answer with the value only."
    return ([{"role": "system", "content": SYSTEM_MSG}, {"role": "user", "content": user}],
            {"n_notes": len(notes), "ctx_chars": len(user)})


class StubScorer:
    """Видит только контекст. scenario: 'debt' | 'nodebt'."""
    def __init__(self, scenario):
        self.scenario = scenario

    def margins(self, messages, meta, cell):
        f = FACTS[cell[0]]
        text = messages[1]["content"]
        lines = [l.split(": ", 1)[1] if ": " in l else l
                 for l in text.split("\n") if l.startswith("Note ")]
        asserts = [l for l in lines if not l.startswith(CORRECTION_MARKERS)]
        corrections = [l for l in lines if l.startswith(CORRECTION_MARKERS)]
        believed = any(f["false"] in l for l in asserts)
        names_false = any(f["false"] in l for l in corrections)
        repaired = bool(corrections)
        depth = sum(1 for l in asserts if f["false"] in l)
        h = int(hashlib.sha256(text.encode()).hexdigest()[:8], 16)
        m = -0.5 + ((h % 1000) / 1000.0 - 0.5) * 0.4
        if believed and not repaired:
            m -= 40.0 + 0.5 * depth
        if names_false:
            m -= 6.0
        if believed and repaired and self.scenario == "debt":
            m -= 1.6
        return -20.0 + m, -20.0, True, 5, 5


class HFScorer:
    def __init__(self):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.torch = torch
        self.tok = AutoTokenizer.from_pretrained(MODEL_ID, revision=MODEL_REV)
        self.model = AutoModelForCausalLM.from_pretrained(
            MODEL_ID, revision=MODEL_REV, torch_dtype=torch.bfloat16, device_map="auto")
        self.model.eval()
        self._cache = {}

    def _score_pair(self, prompt_str, ans_true, ans_false):
        torch = self.torch
        ids_p = self.tok(prompt_str, add_special_tokens=False)["input_ids"]
        outs, oks, ns = [], [], []
        for ans in (ans_true, ans_false):
            ids_f = self.tok(prompt_str + ans, add_special_tokens=False)["input_ids"]
            ok = ids_f[:len(ids_p)] == ids_p
            if not ok:
                ids_f = ids_p + self.tok(ans, add_special_tokens=False)["input_ids"]
            with torch.no_grad():
                t = torch.tensor([ids_f], device=self.model.device)
                lp = torch.log_softmax(self.model(t).logits[0].float(), dim=-1)
            outs.append(sum(float(lp[i - 1, ids_f[i]]) for i in range(len(ids_p), len(ids_f))))
            oks.append(ok)
            ns.append(len(ids_f) - len(ids_p))
        return outs[0], outs[1], (oks[0] and oks[1]), ns[0], ns[1]

    def margins(self, messages, meta, cell):
        f = FACTS[cell[0]]
        prompt_str = self.tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        return self._score_pair(prompt_str, f["true"], f["false"])


def run(scorer, out_dir, scorer_name):
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, "runs.jsonl")
    total = len(FACTS) * len(K_GRID) * len(R_GRID) * len(SEEDS) * len(ARMS) * len(FAMILIES)
    n = 0
    t0 = time.time()
    with open(path, "w", encoding="utf-8") as fh:
        for fi in range(len(FACTS)):
            for k in K_GRID:
                for r in R_GRID:
                    for s in SEEDS:
                        for fam in FAMILIES:
                            for arm in ARMS:
                                cell = (fi, k, r, s, arm, fam)
                                messages, meta = build_context(fi, k, r, s, arm, fam)
                                sha = hashlib.sha256(
                                    json.dumps(messages, ensure_ascii=False).encode()).hexdigest()
                                try:
                                    lp_c, lp_f, pok, n1, n2 = scorer.margins(messages, meta, cell)
                                    ok = lp_c is not None and lp_f is not None and lp_c == lp_c and lp_f == lp_f
                                except Exception:
                                    lp_c = lp_f = None
                                    pok, n1, n2, ok = False, 0, 0, False
                                fh.write(json.dumps({
                                    "fact": FACTS[fi]["id"], "fact_idx": fi, "k": k, "r": r,
                                    "seed": s, "arm": arm, "family": fam,
                                    "lp_correct": lp_c, "lp_false": lp_f,
                                    "margin": (lp_c - lp_f) if ok else None,
                                    "prefix_ok": bool(pok), "n_ans_tokens": [n1, n2],
                                    "n_notes": meta["n_notes"], "ctx_chars": meta["ctx_chars"],
                                    "ctx_sha256": sha, "technical_failure": (not ok),
                                }, ensure_ascii=False) + "\n")
                                n += 1
                                if n % 500 == 0:
                                    el = time.time() - t0
                                    print("  %d/%d  %.1f%%  прошло %.1f мин, осталось ~%.1f мин"
                                          % (n, total, 100.0 * n / total, el / 60,
                                             (el / n * (total - n)) / 60), flush=True)
    man = {"spec": SPEC_VERSION, "model": MODEL_ID, "revision": MODEL_REV, "scorer": scorer_name,
           "k_grid": K_GRID, "r_grid": R_GRID, "seeds": SEEDS, "arms": ARMS,
           "families": FAMILIES, "n_facts": len(FACTS), "n_rows": n,
           "runner_sha256": hashlib.sha256(open(os.path.abspath(__file__), "rb").read()).hexdigest(),
           "facts_sha256": hashlib.sha256(
               open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "e3_facts.py"), "rb").read()).hexdigest(),
           "no_generation": True, "teacher_forcing_only": True,
           "elapsed_sec": round(time.time() - t0, 1),
           "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t0))}
    if scorer_name == "hf":
        try:
            import torch, transformers  # noqa
            man.update({"torch": torch.__version__, "transformers": transformers.__version__,
                        "cuda_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu",
                        "dtype": "bfloat16"})
        except Exception:
            pass
    with open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8") as fh:
        json.dump(man, fh, ensure_ascii=False, indent=2)
    print("rows:", n, "->", path, "за %.1f мин" % ((time.time() - t0) / 60))
    return path


def selftest():
    import tempfile
    import e3_analyze as A
    ok_all = True
    for scen, exp in (("debt", True), ("nodebt", False)):
        d = tempfile.mkdtemp(prefix="e3_%s_" % scen)
        run(StubScorer(scen), d, "stub-" + scen)
        res = A.analyze(os.path.join(d, "runs.jsonl"))
        g = res["gates"]
        ok = (g["identity_pass"] and g["duplicate_pass"] and g["injection_pass"]
              and g["debt_pass"] == exp and g["mention_pass"])
        ok_all = ok_all and ok
        print("[selftest %s] identity=%s dup=%s injection=%s debt=%s (ждали %s) mention=%s -> %s"
              % (scen, g["identity_pass"], g["duplicate_pass"], g["injection_pass"],
                 g["debt_pass"], exp, g["mention_pass"], "PASS" if ok else "FAIL"))
        p = res["primary"]
        print("   долг %d/%d кластеров, p=%.3g, среднее %.3f, CI95 [%.3f, %.3f] | вердикт: %s"
              % (p["debt_neg"], p["debt_n"], p["debt_p"], p["debt_mean"],
                 p["debt_ci95"][0], p["debt_ci95"][1], res["verdict"]))
    print("SELFTEST:", "PASS" if ok_all else "FAIL")
    return 0 if ok_all else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--stub", choices=["debt", "nodebt"])
    ap.add_argument("--out", default="e3_out")
    a = ap.parse_args()
    if a.selftest:
        sys.exit(selftest())
    run(StubScorer(a.stub) if a.stub else HFScorer(), a.out,
        ("stub-" + a.stub) if a.stub else "hf")


if __name__ == "__main__":
    main()
