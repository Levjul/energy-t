#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E3 — независимый анализатор. Читает только runs.jsonl.
Гейты заморожены в E3_SPEC_PREREG_2026-08-27.md.
Детерминированный бутстрэп (фиксированный LCG-сид) — без Math.random по духу правил.
"""
import json, math, statistics, sys

R_REPAIRED = (1, 2)
BOOT_N = 5000
BOOT_SEED = 20260827


def binom_two_sided(n, k):
    pmf = lambda i: math.comb(n, i) * 0.5 ** n
    p = pmf(k)
    return min(1.0, sum(pmf(i) for i in range(n + 1) if pmf(i) <= p + 1e-15))


def boot_ci(vals, n_boot=BOOT_N, seed=BOOT_SEED):
    """Перцентильный бутстрэп среднего. Детерминированный LCG."""
    if not vals:
        return (None, None)
    st = seed & 0xFFFFFFFF
    m = len(vals)
    means = []
    for _ in range(n_boot):
        s = 0.0
        for _ in range(m):
            st = (1103515245 * st + 12345) & 0x7FFFFFFF
            s += vals[st % m]
        means.append(s / m)
    means.sort()
    return (round(means[int(0.025 * n_boot)], 4), round(means[int(0.975 * n_boot) - 1], 4))


def analyze(path):
    rows = [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]
    tech = sum(1 for r in rows if r["technical_failure"])
    prefix_bad = sum(1 for r in rows if not r["prefix_ok"])
    R = {(r["fact"], r["k"], r["r"], r["seed"], r["arm"], r["family"]): r
         for r in rows if not r["technical_failure"]}
    facts = sorted({k[0] for k in R})
    ks = sorted({k[1] for k in R})
    seeds = sorted({k[3] for k in R})
    fams = sorted({k[5] for k in R})

    def g(f, k, r, s, a, fam):
        row = R.get((f, k, r, s, a, fam))
        return row["margin"] if row else None

    # гейт тождества при r=0: mention==base, silent==name (побуквенно, Δ=0)
    id_checks = id_fail = 0
    for f in facts:
        for k in ks:
            for s in seeds:
                for fam in fams:
                    for a, b in (("mention", "base"), ("silent", "name")):
                        ra, rb = R.get((f, k, 0, s, a, fam)), R.get((f, k, 0, s, b, fam))
                        if ra and rb:
                            id_checks += 1
                            if ra["ctx_sha256"] != rb["ctx_sha256"] or ra["margin"] != rb["margin"]:
                                id_fail += 1
    identity_pass = id_checks > 0 and id_fail == 0

    # гейт дублей: при k=0 и r=0 нет ни подкреплений, ни коррекций,
    # поэтому семьи формулировок A и B обязаны дать побуквенно один контекст
    dup_checks = dup_fail = 0
    for f in facts:
        for s in seeds:
            for a in ("base", "name"):
                ra, rb = R.get((f, 0, 0, s, a, "A")), R.get((f, 0, 0, s, a, "B"))
                if ra and rb:
                    dup_checks += 1
                    if ra["ctx_sha256"] != rb["ctx_sha256"] or ra["margin"] != rb["margin"]:
                        dup_fail += 1
    duplicate_pass = dup_checks > 0 and dup_fail == 0

    # инъекция при r=0
    inj = [g(f, k, 0, s, "name", "A") - g(f, k, 0, s, "base", "A")
           for f in facts for k in ks for s in seeds
           if g(f, k, 0, s, "name", "A") is not None and g(f, k, 0, s, "base", "A") is not None]
    inj_neg = sum(1 for v in inj if v < 0)
    injection_pass = len(inj) > 0 and inj_neg >= 0.85 * len(inj)

    def clusters(a, b, fam_filter=None):
        out = []
        for f in facts:
            for s in seeds:
                vals = [g(f, k, r, s, a, fam) - g(f, k, r, s, b, fam)
                        for k in ks for r in R_REPAIRED
                        for fam in (fams if fam_filter is None else [fam_filter])
                        if g(f, k, r, s, a, fam) is not None and g(f, k, r, s, b, fam) is not None]
                if vals:
                    out.append(((f, s), statistics.mean(vals)))
        return out

    def summarize(dl):
        vals = [v for _, v in dl]
        neg = sum(1 for v in vals if v < 0)
        n = len(vals)
        return {"neg": neg, "n": n, "p": binom_two_sided(n, n - neg),
                "mean": round(statistics.mean(vals), 4) if vals else None,
                "median": round(statistics.median(vals), 4) if vals else None,
                "ci95": boot_ci(vals), "share_neg": round(neg / n, 4) if n else None}

    debt = clusters("name", "mention")
    mention = clusters("mention", "base")
    silent = clusters("name", "silent")
    total = clusters("name", "base")
    S = {"debt": summarize(debt), "mention": summarize(mention),
         "silent": summarize(silent), "total": summarize(total)}

    debt_pass = bool(identity_pass and duplicate_pass and injection_pass
                     and S["debt"]["ci95"][1] is not None and S["debt"]["ci95"][1] < 0
                     and S["debt"]["share_neg"] >= 0.65)
    m_pass = bool(S["mention"]["ci95"][1] is not None and S["mention"]["ci95"][1] < 0)

    if debt_pass:
        verdict = "ДОЛГ ПОДТВЕРЖДЁН на расширенном наборе"
    elif m_pass:
        verdict = "долг не подтверждён; дефицит объясняется упоминанием"
    else:
        verdict = "ни долга, ни цены упоминания на этом наборе"

    # по семьям формулировок — проверка устойчивости
    by_family = {fam: {"debt": summarize(clusters("name", "mention", fam)),
                       "mention": summarize(clusters("mention", "base", fam))}
                 for fam in fams}

    # по фактам — гетерогенность
    by_fact = {}
    for f in facts:
        vals = [g(f, k, r, s, "name", fam) - g(f, k, r, s, "mention", fam)
                for k in ks for r in R_REPAIRED for s in seeds for fam in fams
                if g(f, k, r, s, "name", fam) is not None and g(f, k, r, s, "mention", fam) is not None]
        if vals:
            by_fact[f] = round(statistics.mean(vals), 3)
    n_fact_neg = sum(1 for v in by_fact.values() if v < 0)

    def curve(a, b):
        out = {}
        for r in (0,) + R_REPAIRED:
            vals = [g(f, k, r, s, a, fam) - g(f, k, r, s, b, fam)
                    for f in facts for k in ks for s in seeds for fam in fams
                    if g(f, k, r, s, a, fam) is not None and g(f, k, r, s, b, fam) is not None]
            out[str(r)] = round(statistics.mean(vals), 4) if vals else None
        return out

    return {
        "n_rows": len(rows), "technical_failures": tech, "prefix_fallback_rows": prefix_bad,
        "gates": {"identity_pass": identity_pass, "identity_checked": id_checks, "identity_failed": id_fail,
                  "duplicate_pass": duplicate_pass, "duplicate_checked": dup_checks,
                  "duplicate_failed": dup_fail,
                  "injection_pass": bool(injection_pass),
                  "injection_neg": "%d/%d" % (inj_neg, len(inj)),
                  "injection_mean": round(statistics.mean(inj), 4) if inj else None,
                  "debt_pass": debt_pass, "mention_pass": m_pass},
        "primary": {"debt_neg": S["debt"]["neg"], "debt_n": S["debt"]["n"],
                    "debt_p": S["debt"]["p"], "debt_mean": S["debt"]["mean"],
                    "debt_median": S["debt"]["median"], "debt_ci95": S["debt"]["ci95"],
                    "debt_share_neg": S["debt"]["share_neg"]},
        "components": S,
        "by_family": by_family,
        "by_fact_debt_mean": by_fact,
        "facts_with_negative_debt": "%d/%d" % (n_fact_neg, len(by_fact)),
        "curves": {"name_minus_base": curve("name", "base"),
                   "mention_minus_base": curve("mention", "base"),
                   "name_minus_mention": curve("name", "mention"),
                   "name_minus_silent": curve("name", "silent")},
        "verdict": verdict,
    }


if __name__ == "__main__":
    p = sys.argv[1] if len(sys.argv) > 1 else "e3_out/runs.jsonl"
    res = analyze(p)
    with open(p.rsplit("/", 1)[0] + "/analysis.json", "w", encoding="utf-8") as fh:
        json.dump(res, fh, ensure_ascii=False, indent=2)
    print(json.dumps({k: res[k] for k in
                      ("gates", "primary", "components", "by_family",
                       "facts_with_negative_debt", "curves", "verdict")},
                     ensure_ascii=False, indent=2))
