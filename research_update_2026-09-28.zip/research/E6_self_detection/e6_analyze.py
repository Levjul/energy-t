#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""E6 — независимый анализатор. Читает только runs.jsonl.
Гейты заморожены в E6_SPEC_PREREG_2026-08-27.md."""
import json, math, statistics, sys

BOOT_N, BOOT_SEED = 5000, 20260827


def boot_ci(v, n_boot=BOOT_N, seed=BOOT_SEED):
    if not v:
        return (None, None)
    st, m, out = seed & 0xFFFFFFFF, len(v), []
    for _ in range(n_boot):
        s = 0.0
        for _ in range(m):
            st = (1103515245 * st + 12345) & 0x7FFFFFFF
            s += v[st % m]
        out.append(s / m)
    out.sort()
    return (round(out[int(.025 * n_boot)], 4), round(out[int(.975 * n_boot) - 1], 4))


def analyze(path):
    rows = [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]
    tech = sum(1 for r in rows if r["technical_failure"])
    pref = sum(1 for r in rows if not r["prefix_ok"])
    R = {(r["inst"], r["d"], r["seed"], r["arm"], r["probe"]): r
         for r in rows if not r["technical_failure"]}
    insts = sorted({k[0] for k in R})
    ds = sorted({k[1] for k in R})
    seeds = sorted({k[2] for k in R})
    probes = sorted({k[4] for k in R})
    M = lambda i, d, s, a, p: (R.get((i, d, s, a, p)) or {}).get("margin")

    def detect(d, probe=None, arm_ref="mention"):
        """D = margin(contaminated) - margin(ref); >0 значит склонность к 'Yes'."""
        out = []
        for i in insts:
            for s in seeds:
                for p in (probes if probe is None else [probe]):
                    a, b = M(i, d, s, "contaminated", p), M(i, d, s, arm_ref, p)
                    if a is not None and b is not None:
                        out.append(a - b)
        return out

    def summ(v):
        if not v:
            return None
        ci = boot_ci(v)
        return {"mean": round(statistics.mean(v), 4), "median": round(statistics.median(v), 4),
                "ci95": ci, "n": len(v), "pos": sum(1 for x in v if x > 0)}

    by_depth = {str(d): summ(detect(d)) for d in ds}

    # d=0 — калибровочная ячейка: производных узлов нет, противоречия нет ни в одной
    # ветке, но у contaminated ложное значение упомянуто на один раз больше.
    # Поэтому обнаружение считается КАК РАЗНОСТЬ с d=0, парно по (инстанс, сид, зонд).
    def det_minus_base(d):
        out = []
        for i in insts:
            for s in seeds:
                for p in probes:
                    a, b = M(i, d, s, "contaminated", p), M(i, d, s, "mention", p)
                    c, e = M(i, 0, s, "contaminated", p), M(i, 0, s, "mention", p)
                    if None not in (a, b, c, e):
                        out.append((a - b) - (c - e))
        return out

    d0 = detect(0)
    d1 = det_minus_base(1)
    null_ci = boot_ci(d0)
    null_pass = bool(null_ci[0] is not None and abs(statistics.mean(d0)) < 0.5)
    d1_ci = boot_ci(d1)
    detection_pass = bool(d1_ci[0] is not None and d1_ci[0] > 0)
    by_depth_corrected = {str(d): summ(det_minus_base(d)) for d in ds if d > 0}

    # деградация с глубиной
    dmax = max(d for d in ds if d > 0)
    slope = None
    if dmax != 1:
        pairs = []
        for i in insts:
            for s in seeds:
                for p in probes:
                    a = M(i, dmax, s, "contaminated", p); b = M(i, dmax, s, "mention", p)
                    c = M(i, 1, s, "contaminated", p);    e = M(i, 1, s, "mention", p)
                    if None not in (a, b, c, e):
                        pairs.append((a - b) - (c - e))
        slope = summ(pairs)

    # эффект прямого указания искать
    probe_eff = None
    if len(probes) == 2:
        pe = []
        for i in insts:
            for s in seeds:
                for d in [x for x in ds if x > 0]:
                    a = M(i, d, s, "contaminated", "directed"); b = M(i, d, s, "mention", "directed")
                    c = M(i, d, s, "contaminated", "neutral");  e = M(i, d, s, "mention", "neutral")
                    if None not in (a, b, c, e):
                        pe.append((a - b) - (c - e))
        probe_eff = summ(pe)

    verdict = ("ОБНАРУЖИВАЕТ противоречие сама" if detection_pass
               else "НЕ обнаруживает противоречие")

    return {"n_rows": len(rows), "technical_failures": tech, "prefix_fallback_rows": pref,
            "gates": {"null_pass": null_pass, "null_ci95": null_ci,
                      "detection_pass": detection_pass},
            "primary": {"d1_mean": summ(d1)["mean"], "d1_ci95": d1_ci,
                        "d1_pos": summ(d1)["pos"], "d1_n": summ(d1)["n"]},
            "detection_by_depth_raw": {k: (v["mean"] if v else None) for k, v in by_depth.items()},
            "detection_by_depth": {k: (v["mean"] if v else None) for k, v in by_depth_corrected.items()},
            "detection_by_depth_full": by_depth_corrected,
            "depth_slope_dmax_minus_d1": slope,
            "probe_effect_directed_minus_neutral": probe_eff,
            "raw_yes_preference": {
                arm: {str(d): round(statistics.mean(
                    [M(i, d, s, arm, p) for i in insts for s in seeds for p in probes
                     if M(i, d, s, arm, p) is not None]), 4) for d in ds}
                for arm in ("clean", "mention", "contaminated")},
            "verdict": verdict}


if __name__ == "__main__":
    p = sys.argv[1] if len(sys.argv) > 1 else "e6_out/runs.jsonl"
    res = analyze(p)
    json.dump(res, open(p.rsplit("/", 1)[0] + "/analysis.json", "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    print(json.dumps(res, ensure_ascii=False, indent=1))
