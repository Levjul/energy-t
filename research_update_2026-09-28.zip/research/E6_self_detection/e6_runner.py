#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E6 — Способна ли модель обнаружить противоречие сама.
Преджистрация: E6_SPEC_PREREG_2026-08-27.md v0.1. Заморожена до прогона.

Во всех пяти предыдущих экспериментах исправляющий агент был СНАРУЖИ.
Э6 спрашивает модель, есть ли в заметках противоречие, и меряет предпочтение
между заранее заданными "Yes" и "No". Генерации нет, парсинга нет.

Ветки:
  contaminated — корень ложный, цепочка из ложного, коррекция чинит корень.
                 Производные значения теперь ПРОТИВОРЕЧАТ исправленному корню.
  mention      — корень истинный, цепочка истинная, текст коррекции ПОБУКВЕННО
                 как у contaminated (называет ложное значение). Противоречия НЕТ.
  clean        — корень истинный, цепочка истинная, коррекция подтверждает. Нет.

Обнаружение = margin(contaminated) - margin(mention): цена упоминания вычтена.

  python e6_runner.py --selftest
  python e6_runner.py --stub detect|blind --out DIR
  python e6_runner.py --out DIR
"""
import argparse, hashlib, json, os, sys, time
from e4_chains import INSTANCES, NODE, op_text

SPEC_VERSION = "E6_v0.1_2026-08-27"
MODEL_ID = "Qwen/Qwen2.5-7B-Instruct"
MODEL_REV = "a09a35458c702b33eeacc393d103063234e8bc28"
D_GRID = [0, 1, 2, 4]
SEEDS = [1, 2, 3, 4, 5]
ARMS = ["clean", "mention", "contaminated"]
PROBES = {
    "neutral": "Do these notes contain a contradiction? Answer Yes or No.",
    "directed": ("Check whether every step value follows from the corrected base count. "
                 "Do these notes contain an error? Answer Yes or No."),
}
SYSTEM_MSG = "The following working notes were collected in order."
NAME_CORR = ("Correction: the earlier note stating that the base count of {ent} is {bad} "
             "is wrong. The base count of {ent} is {good}.")
CONFIRM_CORR = ("Confirmation: the earlier note stating that the base count of {ent} is {good} "
                "is correct. The base count of {ent} is {good}.")
ANS_YES, ANS_NO = "Yes", "No"


def build_context(ii, d, seed, arm, probe):
    ins = INSTANCES[ii]
    ent = ins["entity"]
    truthful = arm in ("clean", "mention")
    base_v = ins["base_true"] if truthful else ins["base_false"]
    ch = ins["true_chain"] if truthful else ins["false_chain"]
    notes = ["The base count of %s is %d." % (ent, base_v)]
    for j in range(d):
        notes.append("Step %d: %s = %d." % (j + 1, op_text(j), ch[j]))
    tpl = CONFIRM_CORR if arm == "clean" else NAME_CORR
    notes.append(tpl.format(ent=ent, bad=ins["base_false"], good=ins["base_true"]))
    body = "\n".join("Note %d: %s" % (i + 1, s) for i, s in enumerate(notes))
    user = body + "\n\n" + PROBES[probe]
    return ([{"role": "system", "content": SYSTEM_MSG}, {"role": "user", "content": user}],
            {"n_notes": len(notes), "ctx_chars": len(user)})


class StubScorer:
    """Видит только контекст. detect — модель замечает противоречие и слабеет с глубиной."""
    def __init__(self, scenario):
        self.scenario = scenario

    def margins(self, messages, meta, cell):
        ins = INSTANCES[cell[0]]
        text = messages[1]["content"]
        lines = [l.split(": ", 1)[1] if ": " in l else l
                 for l in text.split("\n") if l.startswith("Note ")]
        steps = [l for l in lines if l.startswith("Step")]
        # реальное противоречие: шаги посчитаны из ложного корня, а корень исправлен
        contradiction = any(str(v) in l for l, v in zip(steps, ins["false_chain"]))
        names_false = str(ins["base_false"]) in text.split("Note")[-1]
        directed = "Check whether" in text
        h = int(hashlib.sha256(text.encode()).hexdigest()[:8], 16)
        m = -1.0 + ((h % 1000) / 1000.0 - 0.5) * 0.3     # склонность к "No"
        if names_false:
            m += 0.8                                      # упоминание лжи само тянет к "Yes"
        if contradiction and self.scenario == "detect":
            depth = len(steps)
            m += max(0.0, 3.0 - 0.6 * depth)              # обнаружение слабеет с глубиной
            if directed:
                m += 1.0
        return m, 0.0, True, 1, 1


class HFScorer:
    def __init__(self):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.torch = torch
        self.tok = AutoTokenizer.from_pretrained(MODEL_ID, revision=MODEL_REV)
        self.model = AutoModelForCausalLM.from_pretrained(
            MODEL_ID, revision=MODEL_REV, torch_dtype=torch.bfloat16, device_map="auto")
        self.model.eval()

    def margins(self, messages, meta, cell):
        torch = self.torch
        prompt = self.tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        ids_p = self.tok(prompt, add_special_tokens=False)["input_ids"]
        outs, oks, ns = [], [], []
        for ans in (ANS_YES, ANS_NO):
            ids_f = self.tok(prompt + ans, add_special_tokens=False)["input_ids"]
            ok = ids_f[:len(ids_p)] == ids_p
            if not ok:
                ids_f = ids_p + self.tok(ans, add_special_tokens=False)["input_ids"]
            with torch.no_grad():
                t = torch.tensor([ids_f], device=self.model.device)
                lp = torch.log_softmax(self.model(t).logits[0].float(), dim=-1)
            outs.append(sum(float(lp[i - 1, ids_f[i]]) for i in range(len(ids_p), len(ids_f))))
            oks.append(ok); ns.append(len(ids_f) - len(ids_p))
        return outs[0], outs[1], (oks[0] and oks[1]), ns[0], ns[1]


def run(scorer, out_dir, name):
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, "runs.jsonl")
    total = len(INSTANCES) * len(D_GRID) * len(SEEDS) * len(ARMS) * len(PROBES)
    n, t0 = 0, time.time()
    with open(path, "w", encoding="utf-8") as fh:
        for ii in range(len(INSTANCES)):
            for d in D_GRID:
                for s in SEEDS:
                    for probe in PROBES:
                        for arm in ARMS:
                            cell = (ii, d, s, arm, probe)
                            msgs, meta = build_context(ii, d, s, arm, probe)
                            sha = hashlib.sha256(json.dumps(msgs, ensure_ascii=False).encode()).hexdigest()
                            try:
                                ly, ln, pok, n1, n2 = scorer.margins(msgs, meta, cell)
                                ok = ly is not None and ln is not None and ly == ly and ln == ln
                            except Exception:
                                ly = ln = None; pok, n1, n2, ok = False, 0, 0, False
                            fh.write(json.dumps({
                                "inst": INSTANCES[ii]["id"], "inst_idx": ii, "d": d, "seed": s,
                                "arm": arm, "probe": probe, "lp_yes": ly, "lp_no": ln,
                                "margin": (ly - ln) if ok else None, "prefix_ok": bool(pok),
                                "n_ans_tokens": [n1, n2], "n_notes": meta["n_notes"],
                                "ctx_chars": meta["ctx_chars"], "ctx_sha256": sha,
                                "technical_failure": (not ok)}, ensure_ascii=False) + "\n")
                            n += 1
                            if n % 400 == 0:
                                el = time.time() - t0
                                print("  %d/%d %.0f%%  %.1f мин, осталось ~%.1f мин"
                                      % (n, total, 100.0*n/total, el/60, (el/n*(total-n))/60), flush=True)
    man = {"spec": SPEC_VERSION, "model": MODEL_ID, "revision": MODEL_REV, "scorer": name,
           "d_grid": D_GRID, "seeds": SEEDS, "arms": ARMS, "probes": list(PROBES),
           "n_instances": len(INSTANCES), "n_rows": n,
           "runner_sha256": hashlib.sha256(open(os.path.abspath(__file__), "rb").read()).hexdigest(),
           "no_generation": True, "teacher_forcing_only": True,
           "elapsed_sec": round(time.time()-t0, 1),
           "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t0))}
    if name == "hf":
        try:
            import torch, transformers  # noqa
            man.update({"torch": torch.__version__, "transformers": transformers.__version__,
                        "cuda_device": torch.cuda.get_device_name(0), "dtype": "bfloat16"})
        except Exception:
            pass
    json.dump(man, open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    print("rows:", n, "->", path, "за %.1f мин" % ((time.time()-t0)/60))
    return path


def selftest():
    import tempfile, e6_analyze as A
    ok_all = True
    for scen, exp in (("detect", True), ("blind", False)):
        dd = tempfile.mkdtemp(prefix="e6_%s_" % scen)
        run(StubScorer(scen), dd, "stub-" + scen)
        res = A.analyze(os.path.join(dd, "runs.jsonl"))
        g = res["gates"]
        ok = g["null_pass"] and g["detection_pass"] == exp
        ok_all = ok_all and ok
        print("[selftest %s] null=%s detection=%s (ждали %s) -> %s"
              % (scen, g["null_pass"], g["detection_pass"], exp, "PASS" if ok else "FAIL"))
        p = res["primary"]
        print("   D(d=1) = %+.3f CI95 [%+.3f, %+.3f] | по глубине: %s | %s"
              % (p["d1_mean"], p["d1_ci95"][0], p["d1_ci95"][1],
                 res["detection_by_depth"], res["verdict"]))
    print("SELFTEST:", "PASS" if ok_all else "FAIL")
    return 0 if ok_all else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--stub", choices=["detect", "blind"])
    ap.add_argument("--out", default="e6_out")
    a = ap.parse_args()
    if a.selftest:
        sys.exit(selftest())
    run(StubScorer(a.stub) if a.stub else HFScorer(), a.out,
        ("stub-" + a.stub) if a.stub else "hf")


if __name__ == "__main__":
    main()
