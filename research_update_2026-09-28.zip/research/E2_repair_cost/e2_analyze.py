#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E2 — независимый анализатор. Читает только runs.jsonl, ничего не меняет.
Гейты и конечные точки заморожены в E2_SPEC_PREREG_2026-08-25.md:
  - инъекция: при r=0 S<0 в >=63/84 ячеек, иначе NOT_EVALUABLE;
  - первичная: Delta = D(k=8,r=2) - D(k=0,r=2) > 0 в >=16/21 кластеров (f,s);
  - вторичные: описательные, гейтов не имеют.
"""
import json, math, sys, collections

K_MIN, K_MAX, R_PRIMARY = 0, 8, 2
EPS_TOK = 1.0  # порог "восстановления" для D_tok (нат)


def binom_two_sided(n, k):
    """Точный двусторонний биномиальный тест p=0.5."""
    def pmf(i):
        return math.comb(n, i) * 0.5 ** n
    p_obs = pmf(k)
    return min(1.0, sum(pmf(i) for i in range(n + 1) if pmf(i) <= p_obs + 1e-15))


def analyze(path):
    rows = [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]
    tech_fail = [r for r in rows if r.get("technical_failure")]
    ok_rows = [r for r in rows if not r.get("technical_failure")]
    prefix_bad = [r for r in ok_rows if not r.get("prefix_ok")]

    m = {}
    for r in ok_rows:
        m[(r["fact"], r["k"], r["r"], r["seed"], r["branch"])] = r["margin"]

    # дефицит S по парам
    S = {}
    facts = sorted({r["fact"] for r in ok_rows})
    seeds = sorted({r["seed"] for r in ok_rows})
    ks = sorted({r["k"] for r in ok_rows})
    rs = sorted({r["r"] for r in ok_rows})
    for f in facts:
        for k in ks:
            for rr in rs:
                for s in seeds:
                    a = m.get((f, k, rr, s, "cont"))
                    b = m.get((f, k, rr, s, "base"))
                    if a is not None and b is not None:
                        S[(f, k, rr, s)] = a - b

    # гейт инъекции: r=0
    inj_cells = [(f, k, 0, s) for f in facts for k in ks for s in seeds]
    inj_have = [c for c in inj_cells if c in S]
    inj_neg = [c for c in inj_have if S[c] < 0]
    injection_pass = len(inj_neg) >= 63 and len(inj_have) >= 84

    # первичная точка
    deltas = []
    for f in facts:
        for s in seeds:
            d_hi = S.get((f, K_MAX, R_PRIMARY, s))
            d_lo = S.get((f, K_MIN, R_PRIMARY, s))
            if d_hi is not None and d_lo is not None:
                # D = -S; Delta = D(k=8) - D(k=0) = S(k=0) - S(k=8)
                deltas.append(((f, s), d_lo - d_hi))
    n_pos = sum(1 for _, d in deltas if d > 0)
    p_bin = binom_two_sided(len(deltas), n_pos) if deltas else 1.0
    primary_pass = injection_pass and len(deltas) == 21 and n_pos >= 16

    # вторичные
    curves = {}
    for k in ks:
        curves[str(k)] = {str(rr): round(
            sum(S[c] for c in S if c[1] == k and c[2] == rr) /
            max(1, len([c for c in S if c[1] == k and c[2] == rr])), 4) for rr in rs}
    # Spearman rho(k, D) при r=2
    pts = [(c[1], -S[c]) for c in S if c[2] == R_PRIMARY]
    rho = spearman(pts)
    # D_tok
    dtok = collections.Counter()
    total_cells = 0
    for f in facts:
        for k in ks:
            for s in seeds:
                total_cells += 1
                got = None
                for rr in rs:
                    v = S.get((f, k, rr, s))
                    if v is not None and v >= -EPS_TOK:
                        got = rr
                        break
                dtok["r<=%s" % got if got is not None else ">max"] += 1

    return {
        "n_rows": len(rows), "technical_failures": len(tech_fail),
        "prefix_fallback_rows": len(prefix_bad),
        "gates": {"injection_pass": bool(injection_pass),
                  "injection_neg": "%d/%d" % (len(inj_neg), len(inj_have)),
                  "primary_pass": bool(primary_pass)},
        "primary": {"n_clusters": len(deltas), "n_pos": n_pos,
                    "p_binomial": p_bin,
                    "deltas": {"%s|s%d" % fs: round(d, 4) for fs, d in deltas}},
        "secondary": {"mean_S_by_k_r": curves,
                      "spearman_k_vs_D_at_r2": rho,
                      "recovery_dose_hist": dict(dtok),
                      "recovery_eps_nats": EPS_TOK},
    }


def spearman(pts):
    if len(pts) < 3:
        return None
    def ranks(v):
        order = sorted(range(len(v)), key=lambda i: v[i])
        rk = [0.0] * len(v)
        i = 0
        while i < len(order):
            j = i
            while j + 1 < len(order) and v[order[j + 1]] == v[order[i]]:
                j += 1
            avg = (i + j) / 2.0 + 1
            for t in range(i, j + 1):
                rk[order[t]] = avg
            i = j + 1
        return rk
    xs = ranks([p[0] for p in pts])
    ys = ranks([p[1] for p in pts])
    n = len(pts)
    mx, my = sum(xs) / n, sum(ys) / n
    num = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
    den = math.sqrt(sum((a - mx) ** 2 for a in xs) * sum((b - my) ** 2 for b in ys))
    return round(num / den, 4) if den else None


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "e2_out/runs.jsonl"
    res = analyze(path)
    out = path.rsplit("/", 1)[0] + "/analysis.json"
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(res, fh, ensure_ascii=False, indent=2)
    print(json.dumps({k: res[k] for k in ("gates", "primary")}, ensure_ascii=False, indent=2))
    print("full ->", out)
