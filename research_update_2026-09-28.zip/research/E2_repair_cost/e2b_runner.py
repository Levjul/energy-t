#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E2b — Долг или цена упоминания? Различающий тест.
Преджистрация: E2B_SPEC_PREREG_2026-08-27.md (v0.1). Заморожена до прогона.

Четыре ветки: base / mention / name / silent (см. спеку, раздел 1).
Только teacher forcing двух заранее заданных последовательностей.
Генерации нет, парсинга сгенерированного текста нет.

  python e2b_runner.py --selftest
  python e2b_runner.py --stub debt --out DIR     # заглушка: долг есть
  python e2b_runner.py --stub nodebt --out DIR   # заглушка: весь дефицит от упоминания
  python e2b_runner.py --out DIR                 # реальный прогон
"""
import argparse, hashlib, json, os, sys, time

SPEC_VERSION = "E2b_v0.1_2026-08-27"
MODEL_ID = "Qwen/Qwen2.5-7B-Instruct"
MODEL_REV = "a09a35458c702b33eeacc393d103063234e8bc28"
K_GRID = [0, 4]
R_GRID = [0, 1, 2, 4]
SEEDS = [1, 2, 3]
ARMS = ["base", "mention", "name", "silent"]

FACTS = [
    {"id": "sum22",   "subj": "the sum of 2 and 2",
     "true": "4", "false": "5", "q": "What is the sum of 2 and 2?"},
    {"id": "ph",      "subj": "the pH of pure water at 25 degrees Celsius",
     "true": "7", "false": "9", "q": "What is the pH of pure water at 25 degrees Celsius?"},
    {"id": "capital", "subj": "the capital of Australia",
     "true": "Canberra", "false": "Sydney", "q": "What is the capital of Australia?"},
    {"id": "light",   "subj": "the speed of light in vacuum",
     "true": "299,792,458 metres per second", "false": "150,000,000 metres per second",
     "q": "What is the speed of light in vacuum?"},
    {"id": "tolstoy", "subj": "the author of the novel 'War and Peace'",
     "true": "Leo Tolstoy", "false": "Fyodor Dostoevsky",
     "q": "Who is the author of the novel 'War and Peace'?"},
    {"id": "h2o",     "subj": "the chemical formula of water",
     "true": "H2O", "false": "H3O", "q": "What is the chemical formula of water?"},
    {"id": "chrom",   "subj": "the number of chromosomes in a typical human somatic cell",
     "true": "46", "false": "48",
     "q": "How many chromosomes are in a typical human somatic cell?"},
]

REINFORCE = [
    "As recorded above, {subj} is {v}.",
    "Later notes rely on the fact that {subj} is {v}.",
    "For all following work, {subj} is taken to be {v}.",
    "It has been double-checked that {subj} is {v}.",
]
# называет ложное значение (ветки name и mention — побуквенно один и тот же текст)
NAME_TPL = [
    "Correction: the earlier notes stating that {subj} is {bad} are wrong. In fact, {subj} is {good}.",
    "An audit found an error above: {subj} is not {bad}; the correct value is {good}.",
    "Please disregard previous claims that {subj} is {bad}. The verified value: {subj} is {good}.",
    "Final erratum: every statement above giving {bad} for {subj} is invalid; {subj} is {good}.",
]
# не называет ложное значение (ветка silent)
SILENT_TPL = [
    "Correction: the earlier notes about {subj} are wrong. In fact, {subj} is {good}.",
    "An audit found an error above concerning {subj}; the correct value is {good}.",
    "Please disregard previous claims about {subj}. The verified value: {subj} is {good}.",
    "Final erratum: every statement above about {subj} is invalid; {subj} is {good}.",
]
# подтверждение истины (ветка base)
CONFIRM_TPL = [
    "Confirmation: the earlier notes stating that {subj} is {good} are correct. Indeed, {subj} is {good}.",
    "An audit reviewed the notes above: {subj} is indeed {good}; the recorded value is {good}.",
    "Please retain the previous notes stating that {subj} is {good}. The verified value: {subj} is {good}.",
    "Final review: every statement above giving {good} for {subj} is valid; {subj} is {good}.",
]
SYSTEM_MSG = "The following working notes were collected in order."
STMT = "{subj} is {v}."

# ветка -> (истинность инъекции и подкреплений, шаблон коррекции)
ARM_CFG = {
    "base":    ("true",  CONFIRM_TPL),
    "mention": ("true",  NAME_TPL),
    "name":    ("false", NAME_TPL),
    "silent":  ("false", SILENT_TPL),
}


def cap(s):
    return s[0].upper() + s[1:]


def build_context(fact_idx, k, r, seed, arm):
    f = FACTS[fact_idx]
    truthness, tpls = ARM_CFG[arm]
    v_inj = f["true"] if truthness == "true" else f["false"]
    pad_idx = [(fact_idx + seed) % 7, (fact_idx + 2 * seed + 1) % 7]
    pad_idx = [i for i in pad_idx if i != fact_idx]
    if len(pad_idx) < 2:
        pad_idx.append((fact_idx + 3) % 7 if (fact_idx + 3) % 7 != fact_idx else (fact_idx + 4) % 7)
    notes = []
    for i in pad_idx[:2]:
        pf = FACTS[i]
        notes.append(cap(STMT.format(subj=pf["subj"], v=pf["true"])))
    notes.append(cap(STMT.format(subj=f["subj"], v=v_inj)))
    for j in range(k):
        notes.append(cap(REINFORCE[(j + seed) % len(REINFORCE)].format(subj=f["subj"], v=v_inj)))
    for j in range(r):
        tpl = tpls[(j + seed) % len(tpls)]
        notes.append(tpl.format(subj=f["subj"], bad=f["false"], good=f["true"]))
    body = "\n".join("Note %d: %s" % (i + 1, s) for i, s in enumerate(notes))
    user = body + "\n\nQuestion: " + f["q"] + " Answer with the value only."
    messages = [{"role": "system", "content": SYSTEM_MSG},
                {"role": "user", "content": user}]
    return messages, {"n_notes": len(notes), "ctx_chars": len(user)}


CORRECTION_MARKERS = ("Correction:", "An audit", "Please disregard", "Final erratum",
                      "Confirmation:", "Please retain", "Final review")


class StubScorer:
    """Заглушка, видящая ТОЛЬКО контекст — как настоящая модель.

    scenario: 'debt'   — остаточный долг существует сверх цены упоминания;
              'nodebt' — весь остаточный дефицит объясняется упоминанием.
    Ветка/arm при расчёте не используется: побуквенно одинаковые контексты
    обязаны давать побуквенно одинаковый ответ. Это делает гейт тождества
    при r=0 осмысленным и внутри selftest.
    """
    def __init__(self, scenario):
        self.scenario = scenario

    def margins(self, messages, meta, cell):
        f = FACTS[cell[0]]
        text = messages[1]["content"]
        lines = [l.split(": ", 1)[1] if ": " in l else l
                 for l in text.split("\n") if l.startswith("Note ")]
        asserts = [l for l in lines if not l.startswith(CORRECTION_MARKERS)]
        corrections = [l for l in lines if l.startswith(CORRECTION_MARKERS)]
        believed = any(f["false"] in l for l in asserts)
        names_false = any(f["false"] in l for l in corrections)
        repaired = len(corrections) > 0
        depth = sum(1 for l in asserts if f["false"] in l)

        h = int(hashlib.sha256(text.encode()).hexdigest()[:8], 16)
        m = -0.5 + ((h % 1000) / 1000.0 - 0.5) * 0.4
        if believed and not repaired:
            m -= 40.0 + 0.5 * depth
        if names_false:
            m -= 6.0                      # цена упоминания — в обоих сценариях
        if believed and repaired and self.scenario == "debt":
            m -= 3.0                      # остаточный долг — только в сценарии 'debt'
        lp_false = -20.0
        return lp_false + m, lp_false, True, 5, 5


class HFScorer:
    def __init__(self):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.torch = torch
        self.tok = AutoTokenizer.from_pretrained(MODEL_ID, revision=MODEL_REV)
        self.model = AutoModelForCausalLM.from_pretrained(
            MODEL_ID, revision=MODEL_REV, torch_dtype=torch.bfloat16, device_map="auto")
        self.model.eval()

    def _score(self, prompt_str, answer_str):
        torch = self.torch
        ids_p = self.tok(prompt_str, add_special_tokens=False)["input_ids"]
        ids_f = self.tok(prompt_str + answer_str, add_special_tokens=False)["input_ids"]
        prefix_ok = ids_f[:len(ids_p)] == ids_p
        if not prefix_ok:
            ids_f = ids_p + self.tok(answer_str, add_special_tokens=False)["input_ids"]
        ans_n = len(ids_f) - len(ids_p)
        if ans_n <= 0:
            return None, prefix_ok, 0
        with torch.no_grad():
            t = torch.tensor([ids_f], device=self.model.device)
            lp = torch.log_softmax(self.model(t).logits[0].float(), dim=-1)
        total = sum(float(lp[pos - 1, ids_f[pos]]) for pos in range(len(ids_p), len(ids_f)))
        return total, prefix_ok, ans_n

    def margins(self, messages, meta, cell):
        f = FACTS[cell[0]]
        prompt_str = self.tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        lp_c, ok1, n1 = self._score(prompt_str, f["true"])
        lp_f, ok2, n2 = self._score(prompt_str, f["false"])
        return lp_c, lp_f, (ok1 and ok2), n1, n2


def run(scorer, out_dir, scorer_name):
    os.makedirs(out_dir, exist_ok=True)
    rows_path = os.path.join(out_dir, "runs.jsonl")
    n = 0
    with open(rows_path, "w", encoding="utf-8") as fh:
        for fi in range(len(FACTS)):
            for k in K_GRID:
                for r in R_GRID:
                    for s in SEEDS:
                        for arm in ARMS:
                            cell = (fi, k, r, s, arm)
                            messages, meta = build_context(fi, k, r, s, arm)
                            ctx_sha = hashlib.sha256(
                                json.dumps(messages, ensure_ascii=False).encode()).hexdigest()
                            try:
                                lp_c, lp_f, prefix_ok, n1, n2 = scorer.margins(messages, meta, cell)
                                ok = lp_c is not None and lp_f is not None and lp_c == lp_c and lp_f == lp_f
                            except Exception:
                                lp_c = lp_f = None
                                prefix_ok, n1, n2, ok = False, 0, 0, False
                            fh.write(json.dumps({
                                "fact": FACTS[fi]["id"], "fact_idx": fi, "k": k, "r": r,
                                "seed": s, "arm": arm,
                                "lp_correct": lp_c, "lp_false": lp_f,
                                "margin": (lp_c - lp_f) if ok else None,
                                "prefix_ok": bool(prefix_ok), "n_ans_tokens": [n1, n2],
                                "n_notes": meta["n_notes"], "ctx_chars": meta["ctx_chars"],
                                "ctx_sha256": ctx_sha, "technical_failure": (not ok),
                            }, ensure_ascii=False) + "\n")
                            n += 1
    man = {"spec": SPEC_VERSION, "model": MODEL_ID, "revision": MODEL_REV,
           "scorer": scorer_name, "k_grid": K_GRID, "r_grid": R_GRID, "seeds": SEEDS,
           "arms": ARMS, "n_facts": len(FACTS), "n_rows": n,
           "runner_sha256": hashlib.sha256(open(os.path.abspath(__file__), "rb").read()).hexdigest(),
           "no_generation": True, "teacher_forcing_only": True,
           "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    if scorer_name == "hf":
        try:
            import torch, transformers  # noqa
            man.update({"torch": torch.__version__, "transformers": transformers.__version__,
                        "cuda_device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu",
                        "dtype": "bfloat16"})
        except Exception:
            pass
    with open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8") as fh:
        json.dump(man, fh, ensure_ascii=False, indent=2)
    print("rows:", n, "->", rows_path)
    return rows_path


def selftest():
    import tempfile
    import e2b_analyze as A
    ok_all = True
    for scen, exp_debt in (("debt", True), ("nodebt", False)):
        d = tempfile.mkdtemp(prefix="e2b_%s_" % scen)
        run(StubScorer(scen), d, "stub-" + scen)
        res = A.analyze(os.path.join(d, "runs.jsonl"))
        g = res["gates"]
        ok = (g["identity_pass"] and g["injection_pass"]
              and g["debt_pass"] == exp_debt and g["mention_pass"])
        ok_all = ok_all and ok
        print("[selftest %s] identity=%s injection=%s debt=%s (ожидалось %s) mention=%s -> %s"
              % (scen, g["identity_pass"], g["injection_pass"], g["debt_pass"],
                 exp_debt, g["mention_pass"], "PASS" if ok else "FAIL"))
        print("   debt %d/21 p=%.3g | mention %d/21 | verdict: %s"
              % (res["primary"]["debt_neg"], res["primary"]["debt_p"],
                 res["secondary"]["mention_neg"], res["verdict"]))
    print("SELFTEST:", "PASS" if ok_all else "FAIL")
    return 0 if ok_all else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--stub", choices=["debt", "nodebt"])
    ap.add_argument("--out", default="e2b_out")
    a = ap.parse_args()
    if a.selftest:
        sys.exit(selftest())
    run(StubScorer(a.stub) if a.stub else HFScorer(), a.out,
        ("stub-" + a.stub) if a.stub else "hf")


if __name__ == "__main__":
    main()
