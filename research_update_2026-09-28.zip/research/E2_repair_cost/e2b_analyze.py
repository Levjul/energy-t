#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E2b — независимый анализатор. Читает только runs.jsonl, ничего не меняет.
Гейты заморожены в E2B_SPEC_PREREG_2026-08-27.md:
  4.2 тождество при r=0: mention==base и silent==name побуквенно, Δ ровно 0;
  4.3 инъекция: C(name)-C(base) при r=0 отрицательно в >=32/42;
  4.4 первичная: Δ_debt = C(name)-C(mention) при r in {1,2,4} < 0 в >=16/21 кластеров;
  4.5 вторичные: Δ_mention = C(mention)-C(base), Δ_silent = C(name)-C(silent).
"""
import json, math, statistics, sys

R_REPAIRED = (1, 2, 4)


def binom_two_sided(n, k):
    pmf = lambda i: math.comb(n, i) * 0.5 ** n
    p_obs = pmf(k)
    return min(1.0, sum(pmf(i) for i in range(n + 1) if pmf(i) <= p_obs + 1e-15))


def analyze(path):
    rows = [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]
    tech = sum(1 for r in rows if r["technical_failure"])
    prefix_bad = sum(1 for r in rows if not r["prefix_ok"])
    R = {(r["fact"], r["k"], r["r"], r["seed"], r["arm"]): r
         for r in rows if not r["technical_failure"]}
    facts = sorted({k[0] for k in R})
    ks = sorted({k[1] for k in R})
    seeds = sorted({k[3] for k in R})

    def m(f, k, r, s, arm):
        row = R.get((f, k, r, s, arm))
        return row["margin"] if row else None

    # 4.2 тождество при r=0
    id_checks, id_fail = 0, 0
    for f in facts:
        for k in ks:
            for s in seeds:
                for a, b in (("mention", "base"), ("silent", "name")):
                    ra, rb = R.get((f, k, 0, s, a)), R.get((f, k, 0, s, b))
                    if ra and rb:
                        id_checks += 1
                        if ra["ctx_sha256"] != rb["ctx_sha256"] or ra["margin"] != rb["margin"]:
                            id_fail += 1
    identity_pass = (id_checks > 0 and id_fail == 0)

    # 4.3 инъекция
    inj = [m(f, k, 0, s, "name") - m(f, k, 0, s, "base")
           for f in facts for k in ks for s in seeds
           if m(f, k, 0, s, "name") is not None and m(f, k, 0, s, "base") is not None]
    inj_neg = sum(1 for v in inj if v < 0)
    injection_pass = len(inj) >= 42 and inj_neg >= 32

    # кластерные средние по отремонтированным состояниям
    def cluster_deltas(a, b):
        out = []
        for f in facts:
            for s in seeds:
                vals = [m(f, k, r, s, a) - m(f, k, r, s, b)
                        for k in ks for r in R_REPAIRED
                        if m(f, k, r, s, a) is not None and m(f, k, r, s, b) is not None]
                if vals:
                    out.append(((f, s), statistics.mean(vals)))
        return out

    debt = cluster_deltas("name", "mention")
    mention = cluster_deltas("mention", "base")
    silent = cluster_deltas("name", "silent")
    total = cluster_deltas("name", "base")

    def gate(dl):
        neg = sum(1 for _, v in dl if v < 0)
        return neg, binom_two_sided(len(dl), len(dl) - neg), (len(dl) == 21 and neg >= 16)

    d_neg, d_p, d_pass = gate(debt)
    m_neg, m_p, m_pass = gate(mention)
    s_neg, s_p, s_pass = gate(silent)

    debt_pass = bool(identity_pass and injection_pass and d_pass)
    if debt_pass:
        verdict = "ДОЛГ ЕСТЬ сверх цены упоминания"
    elif m_pass:
        verdict = "пол объясняется упоминанием; долг не показан"
    else:
        verdict = "ни долга, ни цены упоминания; пол требует третьего объяснения"

    def curve(a, b):
        out = {}
        for r in (0,) + R_REPAIRED:
            vals = [m(f, k, r, s, a) - m(f, k, r, s, b)
                    for f in facts for k in ks for s in seeds
                    if m(f, k, r, s, a) is not None and m(f, k, r, s, b) is not None]
            out[str(r)] = round(statistics.mean(vals), 4) if vals else None
        return out

    return {
        "n_rows": len(rows), "technical_failures": tech, "prefix_fallback_rows": prefix_bad,
        "gates": {"identity_pass": identity_pass, "identity_checked": id_checks,
                  "identity_failed": id_fail,
                  "injection_pass": bool(injection_pass),
                  "injection_neg": "%d/%d" % (inj_neg, len(inj)),
                  "injection_mean": round(statistics.mean(inj), 4) if inj else None,
                  "debt_pass": debt_pass, "mention_pass": bool(m_pass),
                  "silent_pass": bool(s_pass)},
        "primary": {"debt_neg": d_neg, "debt_n": len(debt), "debt_p": d_p,
                    "debt_mean": round(statistics.mean(v for _, v in debt), 4) if debt else None,
                    "debt_by_cluster": {"%s|s%d" % c: round(v, 4) for c, v in debt}},
        "secondary": {"mention_neg": m_neg, "mention_p": m_p,
                      "mention_mean": round(statistics.mean(v for _, v in mention), 4) if mention else None,
                      "silent_neg": s_neg, "silent_p": s_p,
                      "silent_mean": round(statistics.mean(v for _, v in silent), 4) if silent else None,
                      "total_deficit_mean": round(statistics.mean(v for _, v in total), 4) if total else None,
                      "curve_name_minus_base": curve("name", "base"),
                      "curve_mention_minus_base": curve("mention", "base"),
                      "curve_name_minus_mention": curve("name", "mention"),
                      "curve_name_minus_silent": curve("name", "silent")},
        "verdict": verdict,
    }


if __name__ == "__main__":
    p = sys.argv[1] if len(sys.argv) > 1 else "e2b_out/runs.jsonl"
    res = analyze(p)
    with open(p.rsplit("/", 1)[0] + "/analysis.json", "w", encoding="utf-8") as fh:
        json.dump(res, fh, ensure_ascii=False, indent=2)
    print(json.dumps({k: res[k] for k in ("gates", "primary", "verdict")},
                     ensure_ascii=False, indent=2))
