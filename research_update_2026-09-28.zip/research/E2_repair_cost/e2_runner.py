#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E2 — Repair Cost (первое прямое измерение «долга»).
Преджистрация: E2_SPEC_PREREG_2026-08-25.md (v0.1). Дизайн заморожен до прогона.

Только teacher forcing двух заранее заданных последовательностей ответа.
Никакой генерации, никакого парсинга сгенерированного текста.

Режимы:
  python e2_runner.py --selftest                 # локальные fixture-тесты на заглушке (без torch)
  python e2_runner.py --stub pos --out DIR       # прогон на заглушке (позитивный сценарий)
  python e2_runner.py --stub neg --out DIR       # прогон на заглушке (негативный контроль)
  python e2_runner.py --out DIR                  # реальный прогон (torch + transformers, GPU)

Выход: DIR/runs.jsonl (raw), DIR/manifest.json. Сводок раннер не пишет —
анализ только отдельным e2_analyze.py.
"""
import argparse, hashlib, json, os, sys, time

SPEC_VERSION = "E2_v0.1_2026-08-25"
MODEL_ID = "Qwen/Qwen2.5-7B-Instruct"
MODEL_REV = "a09a35458c702b33eeacc393d103063234e8bc28"
K_GRID = [0, 2, 4, 8]
R_GRID = [0, 1, 2, 4]
SEEDS = [1, 2, 3]

FACTS = [
    {"id": "sum22",   "subj": "the sum of 2 and 2",
     "true": "4", "false": "5", "q": "What is the sum of 2 and 2?"},
    {"id": "ph",      "subj": "the pH of pure water at 25 degrees Celsius",
     "true": "7", "false": "9", "q": "What is the pH of pure water at 25 degrees Celsius?"},
    {"id": "capital", "subj": "the capital of Australia",
     "true": "Canberra", "false": "Sydney", "q": "What is the capital of Australia?"},
    {"id": "light",   "subj": "the speed of light in vacuum",
     "true": "299,792,458 metres per second", "false": "150,000,000 metres per second",
     "q": "What is the speed of light in vacuum?"},
    {"id": "tolstoy", "subj": "the author of the novel 'War and Peace'",
     "true": "Leo Tolstoy", "false": "Fyodor Dostoevsky",
     "q": "Who is the author of the novel 'War and Peace'?"},
    {"id": "h2o",     "subj": "the chemical formula of water",
     "true": "H2O", "false": "H3O", "q": "What is the chemical formula of water?"},
    {"id": "chrom",   "subj": "the number of chromosomes in a typical human somatic cell",
     "true": "46", "false": "48",
     "q": "How many chromosomes are in a typical human somatic cell?"},
]

REINFORCE = [
    "As recorded above, {subj} is {v}.",
    "Later notes rely on the fact that {subj} is {v}.",
    "For all following work, {subj} is taken to be {v}.",
    "It has been double-checked that {subj} is {v}.",
]
CORRECT_TPL = [
    "Correction: the earlier notes stating that {subj} is {bad} are wrong. In fact, {subj} is {good}.",
    "An audit found an error above: {subj} is not {bad}; the correct value is {good}.",
    "Please disregard previous claims that {subj} is {bad}. The verified value: {subj} is {good}.",
    "Final erratum: every statement above giving {bad} for {subj} is invalid; {subj} is {good}.",
]
CONFIRM_TPL = [
    "Confirmation: the earlier notes stating that {subj} is {good} are correct. Indeed, {subj} is {good}.",
    "An audit reviewed the notes above: {subj} is indeed {good}; the recorded value is {good}.",
    "Please retain the previous notes stating that {subj} is {good}. The verified value: {subj} is {good}.",
    "Final review: every statement above giving {good} for {subj} is valid; {subj} is {good}.",
]
SYSTEM_MSG = "The following working notes were collected in order."
STMT = "{subj} is {v}."


def cap(s):
    return s[0].upper() + s[1:]


def build_context(fact_idx, k, r, seed, branch):
    """branch: 'cont' | 'base'. Возвращает (messages, meta)."""
    f = FACTS[fact_idx]
    v_inj = f["false"] if branch == "cont" else f["true"]
    pad_idx = [(fact_idx + seed) % 7, (fact_idx + 2 * seed + 1) % 7]
    pad_idx = [i for i in pad_idx if i != fact_idx]
    if len(pad_idx) < 2:
        pad_idx.append((fact_idx + 3) % 7 if (fact_idx + 3) % 7 != fact_idx else (fact_idx + 4) % 7)
    notes = []
    for i in pad_idx[:2]:
        pf = FACTS[i]
        notes.append(cap(STMT.format(subj=pf["subj"], v=pf["true"])))
    notes.append(cap(STMT.format(subj=f["subj"], v=v_inj)))
    for j in range(k):
        tpl = REINFORCE[(j + seed) % len(REINFORCE)]
        notes.append(cap(tpl.format(subj=f["subj"], v=v_inj)))
    for j in range(r):
        if branch == "cont":
            tpl = CORRECT_TPL[(j + seed) % len(CORRECT_TPL)]
            notes.append(tpl.format(subj=f["subj"], bad=f["false"], good=f["true"]))
        else:
            tpl = CONFIRM_TPL[(j + seed) % len(CONFIRM_TPL)]
            notes.append(tpl.format(subj=f["subj"], good=f["true"]))
    body = "\n".join("Note %d: %s" % (i + 1, s) for i, s in enumerate(notes))
    user = body + "\n\nQuestion: " + f["q"] + " Answer with the value only."
    messages = [{"role": "system", "content": SYSTEM_MSG},
                {"role": "user", "content": user}]
    meta = {"n_notes": len(notes), "ctx_chars": len(user)}
    return messages, meta


# ---------------- scorers ----------------

class StubScorer:
    """Детерминированная заглушка. scenario: 'pos' (эффект k есть) | 'neg' (нет)."""
    def __init__(self, scenario):
        self.scenario = scenario

    def margins(self, messages, meta, cell):
        fact, k, r, seed, branch = cell
        base = -0.5 - 0.001 * meta["ctx_chars"]
        h = int(hashlib.sha256(("|".join(map(str, cell))).encode()).hexdigest()[:8], 16)
        noise = ((h % 1000) / 1000.0 - 0.5) * 0.6
        if branch == "base":
            m = base + noise * 0.2
        else:
            depth_gain = (1 + 0.35 * k) if self.scenario == "pos" else 1.0
            effect = 8.0 * depth_gain * max(0.0, 1.0 - 0.4 * r)
            m = base - effect + noise
        # margin = lp_correct - lp_false; разложим условно
        lp_false = -20.0
        lp_correct = lp_false + m
        return lp_correct, lp_false, True, 5, 5


class HFScorer:
    def __init__(self):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.torch = torch
        self.tok = AutoTokenizer.from_pretrained(MODEL_ID, revision=MODEL_REV)
        self.model = AutoModelForCausalLM.from_pretrained(
            MODEL_ID, revision=MODEL_REV, torch_dtype=torch.bfloat16, device_map="auto")
        self.model.eval()

    def _score(self, prompt_str, answer_str):
        torch = self.torch
        ids_p = self.tok(prompt_str, add_special_tokens=False)["input_ids"]
        ids_f = self.tok(prompt_str + answer_str, add_special_tokens=False)["input_ids"]
        prefix_ok = ids_f[:len(ids_p)] == ids_p
        if not prefix_ok:
            ans_ids = self.tok(answer_str, add_special_tokens=False)["input_ids"]
            ids_f = ids_p + ans_ids
        ans_ids = ids_f[len(ids_p):]
        if len(ans_ids) == 0:
            return None, prefix_ok, 0
        with torch.no_grad():
            t = torch.tensor([ids_f], device=self.model.device)
            logits = self.model(t).logits[0]
            logprobs = torch.log_softmax(logits.float(), dim=-1)
        total = 0.0
        for pos in range(len(ids_p), len(ids_f)):
            total += float(logprobs[pos - 1, ids_f[pos]])
        return total, prefix_ok, len(ans_ids)

    def margins(self, messages, meta, cell):
        fact_idx = cell[0]
        f = FACTS[fact_idx]
        prompt_str = self.tok.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True)
        lp_c, ok1, n1 = self._score(prompt_str, f["true"])
        lp_f, ok2, n2 = self._score(prompt_str, f["false"])
        return lp_c, lp_f, (ok1 and ok2), n1, n2


# ---------------- run ----------------

def run(scorer, out_dir, scorer_name):
    os.makedirs(out_dir, exist_ok=True)
    rows_path = os.path.join(out_dir, "runs.jsonl")
    n_rows = 0
    with open(rows_path, "w", encoding="utf-8") as fh:
        for fi in range(len(FACTS)):
            for k in K_GRID:
                for r in R_GRID:
                    for s in SEEDS:
                        for branch in ("cont", "base"):
                            cell = (fi, k, r, s, branch)
                            messages, meta = build_context(fi, k, r, s, branch)
                            ctx_sha = hashlib.sha256(
                                json.dumps(messages, ensure_ascii=False).encode()).hexdigest()
                            try:
                                lp_c, lp_f, prefix_ok, n1, n2 = scorer.margins(messages, meta, cell)
                                ok = (lp_c is not None and lp_f is not None
                                      and lp_c == lp_c and lp_f == lp_f)
                            except Exception as e:  # noqa
                                lp_c = lp_f = None
                                prefix_ok, n1, n2, ok = False, 0, 0, False
                            row = {"fact": FACTS[fi]["id"], "fact_idx": fi, "k": k, "r": r,
                                   "seed": s, "branch": branch,
                                   "lp_correct": lp_c, "lp_false": lp_f,
                                   "margin": (lp_c - lp_f) if ok else None,
                                   "prefix_ok": bool(prefix_ok),
                                   "n_ans_tokens": [n1, n2],
                                   "n_notes": meta["n_notes"], "ctx_chars": meta["ctx_chars"],
                                   "ctx_sha256": ctx_sha,
                                   "technical_failure": (not ok)}
                            fh.write(json.dumps(row, ensure_ascii=False) + "\n")
                            n_rows += 1
    self_sha = hashlib.sha256(open(os.path.abspath(__file__), "rb").read()).hexdigest()
    manifest = {"spec": SPEC_VERSION, "model": MODEL_ID, "revision": MODEL_REV,
                "scorer": scorer_name, "k_grid": K_GRID, "r_grid": R_GRID,
                "seeds": SEEDS, "n_facts": len(FACTS), "n_rows": n_rows,
                "runner_sha256": self_sha,
                "no_generation": True, "teacher_forcing_only": True,
                "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    if scorer_name == "hf":
        try:
            import torch, transformers  # noqa
            manifest["torch"] = torch.__version__
            manifest["transformers"] = transformers.__version__
            manifest["cuda_device"] = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu"
            manifest["dtype"] = "bfloat16"
        except Exception:
            pass
    with open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, ensure_ascii=False, indent=2)
    print("rows:", n_rows, "->", rows_path)
    return rows_path


def selftest():
    import tempfile
    import e2_analyze as A
    okall = True
    for scen, expect_primary in (("pos", True), ("neg", False)):
        d = tempfile.mkdtemp(prefix="e2_%s_" % scen)
        run(StubScorer(scen), d, "stub-" + scen)
        res = A.analyze(os.path.join(d, "runs.jsonl"))
        gi = res["gates"]["injection_pass"]
        gp = res["gates"]["primary_pass"]
        ok = gi and (gp == expect_primary)
        okall = okall and ok
        print("[selftest %s] injection=%s primary=%s (expected primary=%s) -> %s"
              % (scen, gi, gp, expect_primary, "PASS" if ok else "FAIL"))
        print("   delta>0 clusters: %d/21, binom p=%.3g"
              % (res["primary"]["n_pos"], res["primary"]["p_binomial"]))
    print("SELFTEST:", "PASS" if okall else "FAIL")
    return 0 if okall else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--stub", choices=["pos", "neg"])
    ap.add_argument("--out", default="e2_out")
    a = ap.parse_args()
    if a.selftest:
        sys.exit(selftest())
    if a.stub:
        run(StubScorer(a.stub), a.out, "stub-" + a.stub)
    else:
        run(HFScorer(), a.out, "hf")


if __name__ == "__main__":
    main()
