# -*- coding: utf-8 -*-
"""E7 — 20 инстансов. Заморожено до прогона вместе со спекой.

Каждый инстанс: имя сущности, истинная база t, ложная база f.
Шаг всегда один и тот же по форме: P = 2 x база.
  верное значение шага  = 2t
  неверное значение шага = 2f  (то самое, что осталось бы от ложной базы)

Требования, проверяемые assert'ами ниже:
  t != f; 2t != 2f; ни одно из чисел t, f, 2t, 2f не совпадает с другим
  из этой же четвёрки — иначе одно и то же число значило бы в заметках разное.
  Все 20 арифметических пар (t, f) различны — в Э4/Э6 их было всего четыре.
"""

INSTANCES = [
    {"id": "batchQ7",   "entity": "batch Q7",   "t": 3,  "f": 5},
    {"id": "lotM3",     "entity": "lot M3",     "t": 4,  "f": 7},
    {"id": "shipmentK9","entity": "shipment K9","t": 5,  "f": 9},
    {"id": "seriesB4",  "entity": "series B4",  "t": 6,  "f": 11},
    {"id": "runT2",     "entity": "run T2",     "t": 7,  "f": 13},
    {"id": "trayL8",    "entity": "tray L8",    "t": 8,  "f": 15},
    {"id": "crateD5",   "entity": "crate D5",   "t": 9,  "f": 17},
    {"id": "palletR1",  "entity": "pallet R1",  "t": 11, "f": 4},
    {"id": "unitV6",    "entity": "unit V6",    "t": 12, "f": 5},
    {"id": "caseN4",    "entity": "case N4",    "t": 13, "f": 6},
    {"id": "sampleP2",  "entity": "sample P2",  "t": 14, "f": 9},
    {"id": "blockG7",   "entity": "block G7",   "t": 15, "f": 8},
    {"id": "reelH3",    "entity": "reel H3",    "t": 16, "f": 21},
    {"id": "spoolW5",   "entity": "spool W5",   "t": 17, "f": 23},
    {"id": "binZ8",     "entity": "bin Z8",     "t": 18, "f": 25},
    {"id": "rackC6",    "entity": "rack C6",    "t": 19, "f": 27},
    {"id": "tubeJ1",    "entity": "tube J1",    "t": 21, "f": 16},
    {"id": "frameY9",   "entity": "frame Y9",   "t": 22, "f": 31},
    {"id": "panelX4",   "entity": "panel X4",   "t": 23, "f": 18},
    {"id": "coilF2",    "entity": "coil F2",    "t": 24, "f": 33},
]

for _i in INSTANCES:
    _q = [_i["t"], _i["f"], 2 * _i["t"], 2 * _i["f"]]
    assert len(set(_q)) == 4, ("числа внутри инстанса повторяются", _i, _q)
assert len({i["id"] for i in INSTANCES}) == len(INSTANCES)
assert len({(i["t"], i["f"]) for i in INSTANCES}) == len(INSTANCES), "арифметические пары не уникальны"
