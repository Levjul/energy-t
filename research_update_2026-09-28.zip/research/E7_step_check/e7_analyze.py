#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""E7 — независимый анализатор. Читает только runs.jsonl.
Гейты заморожены в E7_SPEC_PREREG_2026-08-27.md."""
import json, statistics, sys

BOOT_N, BOOT_SEED = 5000, 20260827


def boot_ci(v, n_boot=BOOT_N, seed=BOOT_SEED):
    if not v:
        return (None, None)
    st, m, out = seed & 0xFFFFFFFF, len(v), []
    for _ in range(n_boot):
        s = 0.0
        for _ in range(m):
            st = (1103515245 * st + 12345) & 0x7FFFFFFF
            s += v[st % m]
        out.append(s / m)
    out.sort()
    return (round(out[int(.025 * n_boot)], 4), round(out[int(.975 * n_boot) - 1], 4))


def analyze(path):
    rows = [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]
    tech = sum(1 for r in rows if r["technical_failure"])
    pref = sum(1 for r in rows if not r["prefix_ok"])
    M = {(r["inst"], r["cond"], r["arm"]): r["margin"]
         for r in rows if not r["technical_failure"]}
    S = {(r["inst"], r["cond"], r["arm"]): r["ctx_sha256"]
         for r in rows if not r["technical_failure"]}
    insts = sorted({k[0] for k in M})

    # гейт различимости: ok и bad обязаны быть РАЗНЫМИ контекстами
    distinct = all(S.get((i, c, "ok")) != S.get((i, c, "bad"))
                   for i in insts for c in ("direct", "corrected"))
    # гейт дублей: все 80 контекстов различны
    all_sha = [S[k] for k in sorted(S)]
    no_dupes = len(set(all_sha)) == len(all_sha)

    def det(cond):
        return [M[(i, cond, "ok")] - M[(i, cond, "bad")] for i in insts
                if (i, cond, "ok") in M and (i, cond, "bad") in M]

    def summ(v):
        if not v:
            return {"mean": None, "median": None, "ci95": (None, None), "n": 0, "pos": 0}
        return {"mean": round(statistics.mean(v), 4), "median": round(statistics.median(v), 4),
                "ci95": boot_ci(v), "n": len(v), "pos": sum(1 for x in v if x > 0)}

    d_dir, d_cor = det("direct"), det("corrected")
    delta = [a - b for a, b in zip(d_cor, d_dir)]

    lo_dir = boot_ci(d_dir)[0]
    lo_cor = boot_ci(d_cor)[0]
    primary_pass = bool(distinct and no_dupes and tech == 0 and lo_dir is not None and lo_dir > 0)
    corrected_pass = bool(lo_cor is not None and lo_cor > 0)

    if not primary_pass:
        verdict = "НЕ ПРОВЕРЯЕТ: даже без коррекции модель не отличает следующий шаг от не следующего"
    elif corrected_pass:
        verdict = "ПРОВЕРЯЕТ в обоих условиях; величину смотреть в дельте"
    else:
        verdict = "ПРОВЕРЯЕТ напрямую, но ПЕРЕСТАЁТ после коррекции корня"

    return {"n_rows": len(rows), "technical_failures": tech, "prefix_fallback_rows": pref,
            "gates": {"contexts_distinct": distinct, "no_duplicate_contexts": no_dupes,
                      "primary_pass": primary_pass, "corrected_pass": corrected_pass},
            "direct": summ(d_dir),
            "corrected": summ(d_cor),
            "corrected_minus_direct": summ(delta),
            "raw_margin_means": {
                "%s_%s" % (c, a): round(statistics.mean(
                    [M[(i, c, a)] for i in insts if (i, c, a) in M]), 4)
                for c in ("direct", "corrected") for a in ("ok", "bad")},
            "verdict": verdict}


if __name__ == "__main__":
    p = sys.argv[1] if len(sys.argv) > 1 else "e7_out/runs.jsonl"
    res = analyze(p)
    json.dump(res, open(p.rsplit("/", 1)[0] + "/analysis.json", "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    print(json.dumps(res, ensure_ascii=False, indent=1))
