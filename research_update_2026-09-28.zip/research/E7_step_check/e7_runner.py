#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E7 — Проверяет ли модель, что шаг следует из базы.
Преджистрация: E7_SPEC_PREREG_2026-08-27.md v0.1. Заморожена до прогона.

Одна ось, две ветки, один вопрос. Никаких глубин, зондов, сидов и контрольных
веток: контроль упоминания встроен в сам контраст — тексты `ok` и `bad` внутри
одного условия побуквенно совпадают всюду, кроме последнего числа.

  условие direct     Note 1: база = t
                     Note 2: Step 1: P = 2 x база = 2t   (ok)  |  = 2f   (bad)

  условие corrected  Note 1: база = f
                     Note 2: Correction: ... база = f неверно. база = t.
                     Note 3: Step 1: P = 2 x база = 2t   (ok)  |  = 2f   (bad)

  Вопрос: Does the value of P follow from the base count? Answer Yes or No.
  C = log P("Yes") - log P("No"). Генерации нет, парсинга нет.

  python e7_runner.py --selftest
  python e7_runner.py --out DIR
"""
import argparse, hashlib, json, os, sys, time
from e7_chains import INSTANCES

SPEC_VERSION = "E7_v0.1_2026-08-27"
MODEL_ID = "Qwen/Qwen2.5-7B-Instruct"
MODEL_REV = "a09a35458c702b33eeacc393d103063234e8bc28"
CONDITIONS = ["direct", "corrected"]
ARMS = ["ok", "bad"]
SYSTEM_MSG = "The following working notes were collected in order."
QUESTION = "Does the value of P follow from the base count? Answer Yes or No."
CORR = ("Correction: the earlier note stating that the base count of {e} is {f} "
        "is wrong. The base count of {e} is {t}.")
ANS_YES, ANS_NO = "Yes", "No"


def build_context(ii, cond, arm):
    ins = INSTANCES[ii]
    e, t, f = ins["entity"], ins["t"], ins["f"]
    step = 2 * t if arm == "ok" else 2 * f
    if cond == "direct":
        notes = ["The base count of %s is %d." % (e, t)]
    else:
        notes = ["The base count of %s is %d." % (e, f), CORR.format(e=e, f=f, t=t)]
    notes.append("Step 1: value P = 2 x the base count = %d." % step)
    body = "\n".join("Note %d: %s" % (i + 1, s) for i, s in enumerate(notes))
    user = body + "\n\n" + QUESTION
    return [{"role": "system", "content": SYSTEM_MSG}, {"role": "user", "content": user}]


def structural_check():
    """Гейт формы: внутри условия ok и bad обязаны совпадать всюду, кроме
    последнего числа. Проверяется до прогона, на всех 20 инстансах."""
    bad = []
    for ii in range(len(INSTANCES)):
        for cond in CONDITIONS:
            a = build_context(ii, cond, "ok")[1]["content"]
            b = build_context(ii, cond, "bad")[1]["content"]
            if a.rsplit(" = ", 1)[0] != b.rsplit(" = ", 1)[0] or a == b:
                bad.append((INSTANCES[ii]["id"], cond))
    return (len(bad) == 0), bad


class StubScorer:
    """Видит только контекст. Считает арифметику сама, как это делал бы
    работающий проверяющий. sighted — умеет; blind — не умеет."""
    def __init__(self, scenario):
        self.scenario = scenario

    def margins(self, messages, cell):
        text = messages[1]["content"]
        base = None
        for line in text.split("\n"):
            if "Correction:" in line:
                base = int(line.rstrip(".").rsplit(" is ", 1)[1])
            elif "The base count of" in line and base is None:
                base = int(line.rstrip(".").rsplit(" is ", 1)[1])
        step = int(text.split("Step 1:")[1].split(" = ")[-1].split(".")[0].strip())
        h = int(hashlib.sha256(text.encode()).hexdigest()[:8], 16)
        m = ((h % 1000) / 1000.0 - 0.5) * 0.3
        if self.scenario == "sighted":
            m += 2.0 if step == 2 * base else -2.0
        return m, 0.0, True, 1, 1


class HFScorer:
    def __init__(self):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.torch = torch
        self.tok = AutoTokenizer.from_pretrained(MODEL_ID, revision=MODEL_REV)
        self.model = AutoModelForCausalLM.from_pretrained(
            MODEL_ID, revision=MODEL_REV, dtype=torch.bfloat16, device_map="auto")
        self.model.eval()

    def margins(self, messages, cell):
        torch = self.torch
        prompt = self.tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        ids_p = self.tok(prompt, add_special_tokens=False)["input_ids"]
        outs, oks = [], []
        for ans in (ANS_YES, ANS_NO):
            ids_f = self.tok(prompt + ans, add_special_tokens=False)["input_ids"]
            ok = ids_f[:len(ids_p)] == ids_p
            if not ok:
                ids_f = ids_p + self.tok(ans, add_special_tokens=False)["input_ids"]
            with torch.no_grad():
                tt = torch.tensor([ids_f], device=self.model.device)
                lp = torch.log_softmax(self.model(tt).logits[0].float(), dim=-1)
            outs.append(sum(float(lp[i - 1, ids_f[i]]) for i in range(len(ids_p), len(ids_f))))
            oks.append(ok)
        return outs[0], outs[1], (oks[0] and oks[1]), 1, 1


def run(scorer, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, "runs.jsonl")
    t0, n = time.time(), 0
    with open(path, "w", encoding="utf-8") as fh:
        for ii in range(len(INSTANCES)):
            for cond in CONDITIONS:
                for arm in ARMS:
                    msgs = build_context(ii, cond, arm)
                    sha = hashlib.sha256(json.dumps(msgs, ensure_ascii=False).encode()).hexdigest()
                    try:
                        ly, ln, pok, _, _ = scorer.margins(msgs, (ii, cond, arm))
                        ok = ly == ly and ln == ln
                    except Exception:
                        ly = ln = None; pok, ok = False, False
                    fh.write(json.dumps({
                        "inst": INSTANCES[ii]["id"], "inst_idx": ii, "cond": cond, "arm": arm,
                        "t": INSTANCES[ii]["t"], "f": INSTANCES[ii]["f"],
                        "lp_yes": ly, "lp_no": ln, "margin": (ly - ln) if ok else None,
                        "prefix_ok": bool(pok), "ctx_chars": len(msgs[1]["content"]),
                        "ctx_sha256": sha, "technical_failure": not ok}, ensure_ascii=False) + "\n")
                    n += 1
    ok_struct, bad = structural_check()
    json.dump({"spec": SPEC_VERSION, "model": MODEL_ID, "revision": MODEL_REV,
               "conditions": CONDITIONS, "arms": ARMS, "n_instances": len(INSTANCES),
               "n_rows": n, "seeds": "нет — ось, не меняющая контекст, не ось",
               "structural_gate_pass": ok_struct, "structural_gate_failures": bad,
               "runner_sha256": hashlib.sha256(open(__file__, "rb").read()).hexdigest(),
               "chains_sha256": hashlib.sha256(
                   open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                     "e7_chains.py"), "rb").read()).hexdigest(),
               "no_generation": True, "teacher_forcing_only": True,
               "elapsed_sec": round(time.time() - t0, 1),
               "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t0))},
              open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    print("rows: %d -> %s за %.1f мин" % (n, path, (time.time() - t0) / 60))
    return path


def selftest():
    import tempfile, e7_analyze
    ok_struct, bad = structural_check()
    print("[гейт формы] ok=%s%s" % (ok_struct, "" if ok_struct else (" провалы: %s" % bad)))
    good = ok_struct
    for scen, expect in (("sighted", True), ("blind", False)):
        d = tempfile.mkdtemp(prefix="e7_%s_" % scen)
        p = run(StubScorer(scen), d)
        r = e7_analyze.analyze(p)
        got = r["gates"]["primary_pass"]
        ok = (got == expect)
        good = good and ok
        print("[selftest %-7s] primary=%s (ждали %s) -> %s" % (scen, got, expect, "PASS" if ok else "FAIL"))
        print("   техотказов=%d, дублей нет=%s, контексты различны=%s"
              % (r["technical_failures"], r["gates"]["no_duplicate_contexts"],
                 r["gates"]["contexts_distinct"]))
        print("   Det_direct = %+.3f CI95 %s | Det_corrected = %+.3f CI95 %s"
              % (r["direct"]["mean"], r["direct"]["ci95"],
                 r["corrected"]["mean"], r["corrected"]["ci95"]))
    print("SELFTEST:", "PASS" if good else "FAIL")
    return 0 if good else 1


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--out", default="e7_out")
    a = ap.parse_args()
    if a.selftest:
        sys.exit(selftest())
    ok_struct, bad = structural_check()
    if not ok_struct:
        print("ГЕЙТ ФОРМЫ ПРОВАЛЕН, прогон не запускается:", bad); sys.exit(2)
    run(HFScorer(), a.out)
