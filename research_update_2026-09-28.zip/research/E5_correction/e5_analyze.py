#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""E5 — независимый анализатор. Читает только runs.jsonl.
Гейты заморожены в E5_SPEC_PREREG_2026-08-27.md."""
import json, math, statistics, sys

BOOT_N, BOOT_SEED = 5000, 20260827


def boot_ci(v, n_boot=BOOT_N, seed=BOOT_SEED):
    if not v:
        return (None, None)
    st, m, out = seed & 0xFFFFFFFF, len(v), []
    for _ in range(n_boot):
        s = 0.0
        for _ in range(m):
            st = (1103515245 * st + 12345) & 0x7FFFFFFF
            s += v[st % m]
        out.append(s / m)
    out.sort()
    return (round(out[int(.025 * n_boot)], 4), round(out[int(.975 * n_boot) - 1], 4))


def analyze(path):
    rows = [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]
    tech = sum(1 for r in rows if r["technical_failure"])
    pref = sum(1 for r in rows if not r["prefix_ok"])
    R = {(r["fact"], r["variant"], r["seed"], r["arm"]): r
         for r in rows if not r["technical_failure"]}
    facts = sorted({k[0] for k in R})
    variants = sorted({k[1] for k in R})
    seeds = sorted({k[2] for k in R})
    M = lambda f, v, s, a: (R.get((f, v, s, a)) or {}).get("margin")

    # остаток каждого варианта: name - base (полный) и name - mention (очищенный)
    def resid(v, a="name", b="base"):
        return [M(f, v, s, a) - M(f, v, s, b) for f in facts for s in seeds
                if M(f, v, s, a) is not None and M(f, v, s, b) is not None]

    by_variant = {}
    for v in variants:
        tot, clean = resid(v), resid(v, "name", "mention")
        by_variant[v] = {
            "residual_total_mean": round(statistics.mean(tot), 4),
            "residual_total_ci95": boot_ci(tot),
            "residual_clean_mean": round(statistics.mean(clean), 4),
            "residual_clean_ci95": boot_ci(clean),
            "n": len(tot)}

    def paired(va, vb, a="name", b="mention"):
        out = []
        for f in facts:
            for s in seeds:
                x, y = M(f, va, s, a), M(f, va, s, b)
                p, q = M(f, vb, s, a), M(f, vb, s, b)
                if None not in (x, y, p, q):
                    out.append((x - y) - (p - q))
        return out

    # Все первичные контрасты — на ОЧИЩЕННОМ остатке (name - mention),
    # то есть с вычтенной ценой упоминания, по уроку Э2b.
    # P1 позиция: ранняя минус поздняя (называющие). Отрицательно = ранняя хуже.
    pos = paired("early_name", "late_name")
    # P2 называние: называющая минус молчащая (поздние). Положительно = называть лучше.
    nam = paired("late_name", "late_silent")
    # P3 повтор истины: удвоенная минус обычная. Положительно = повтор помогает.
    twice = paired("late_name_x2", "late_name")

    def summ(v):
        ci = boot_ci(v)
        return {"mean": round(statistics.mean(v), 4), "median": round(statistics.median(v), 4),
                "ci95": ci, "n": len(v), "neg": sum(1 for x in v if x < 0)}

    P = {"position": summ(pos), "naming": summ(nam), "truth_twice": summ(twice)}
    gates = {"position_effect_pass": bool(P["position"]["ci95"][1] is not None
                                          and P["position"]["ci95"][1] < 0),
             "naming_effect_pass": bool(P["naming"]["ci95"][0] is not None
                                        and P["naming"]["ci95"][0] > 0),
             "truth_twice_pass": bool(P["truth_twice"]["ci95"][0] is not None
                                      and P["truth_twice"]["ci95"][0] > 0)}
    best = min(by_variant, key=lambda v: -by_variant[v]["residual_total_mean"])
    worst = min(by_variant, key=lambda v: by_variant[v]["residual_total_mean"])
    return {"n_rows": len(rows), "technical_failures": tech, "prefix_fallback_rows": pref,
            "gates": gates, "primary": P, "by_variant": by_variant,
            "best_variant": best, "worst_variant": worst}


if __name__ == "__main__":
    p = sys.argv[1] if len(sys.argv) > 1 else "e5_out/runs.jsonl"
    res = analyze(p)
    json.dump(res, open(p.rsplit("/", 1)[0] + "/analysis.json", "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    print(json.dumps(res, ensure_ascii=False, indent=1))
