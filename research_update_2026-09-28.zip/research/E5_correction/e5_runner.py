#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
E5 — Эффективность коррекции: что делает исправление работающим.
Преджистрация: E5_SPEC_PREREG_2026-08-27.md v0.1. Заморожена до прогона.

Честный разворот темы: Э2/Э2b/Э3 меряли остаток после коррекции. Э5 признаёт
это предметом и варьирует СВОЙСТВА коррекции, а не их количество.

Пять вариантов коррекции (V), три ветки (base/mention/name).
Только teacher forcing. Генерации нет.
  python e5_runner.py --selftest
  python e5_runner.py --stub pos|neg --out DIR
  python e5_runner.py --out DIR
"""
import argparse, hashlib, json, os, sys, time
from e3_facts import FACTS

SPEC_VERSION = "E5_v0.1_2026-08-27"
MODEL_ID = "Qwen/Qwen2.5-7B-Instruct"
MODEL_REV = "a09a35458c702b33eeacc393d103063234e8bc28"
K = 4                       # подкреплений всегда 4
SEEDS = [1, 2, 3]
ARMS = ["base", "mention", "name"]
# варианты коррекции: (позиция, называет ли ложь, повтор истины)
VARIANTS = {
    "late_name":    {"pos": "late",  "names": True,  "twice": False},
    "late_silent":  {"pos": "late",  "names": False, "twice": False},
    "early_name":   {"pos": "early", "names": True,  "twice": False},
    "early_silent": {"pos": "early", "names": False, "twice": False},
    "late_name_x2": {"pos": "late",  "names": True,  "twice": True},
}
SYSTEM_MSG = "The following working notes were collected in order."
REINFORCE = ["As recorded above, {subj} is {v}.",
             "Later notes rely on the fact that {subj} is {v}.",
             "For all following work, {subj} is taken to be {v}.",
             "It has been double-checked that {subj} is {v}."]
CORRECTION_MARKERS = ("Correction:", "Confirmation:")


def cap(s):
    return s[0].upper() + s[1:]


def correction_text(f, v, arm):
    """Одна строка коррекции по варианту и ветке."""
    subj, good, bad = f["subj"], f["true"], f["false"]
    if arm == "base":                       # подтверждение истины, ложь не называется
        body = "the earlier notes about %s are correct. %s is %s." % (subj, cap(subj), good)
    elif v["names"]:                        # называет ложное значение
        body = "the earlier notes stating that %s is %s are wrong. %s is %s." % (
            subj, bad, cap(subj), good)
    else:                                   # не называет
        body = "the earlier notes about %s are wrong. %s is %s." % (subj, cap(subj), good)
    if v["twice"]:
        body += " Again: %s is %s." % (subj, good)
    head = "Confirmation: " if arm == "base" else "Correction: "
    return head + body


def build_context(fi, vname, seed, arm):
    f = FACTS[fi]
    v = VARIANTS[vname]
    truthful = arm in ("base", "mention")
    v_inj = f["true"] if truthful else f["false"]
    n = len(FACTS)
    pads, step = [], 1
    while len(pads) < 2:
        j = (fi + seed * 7 + step * 13) % n
        if j != fi and j not in pads:
            pads.append(j)
        step += 1
    notes = [cap("%s is %s." % (FACTS[j]["subj"], FACTS[j]["true"])) for j in pads]
    notes.append(cap("%s is %s." % (f["subj"], v_inj)))
    corr = correction_text(f, v, arm)
    rein = [cap(REINFORCE[(j + seed) % len(REINFORCE)].format(subj=f["subj"], v=v_inj))
            for j in range(K)]
    if v["pos"] == "early":
        notes.append(corr)                  # сразу после лжи, до подкреплений
        notes += rein
    else:
        notes += rein
        notes.append(corr)                  # после всех подкреплений
    body = "\n".join("Note %d: %s" % (i + 1, s) for i, s in enumerate(notes))
    user = body + "\n\nQuestion: " + f["q"] + " Answer with the value only."
    return ([{"role": "system", "content": SYSTEM_MSG}, {"role": "user", "content": user}],
            {"n_notes": len(notes), "ctx_chars": len(user)})


class StubScorer:
    """Видит только контекст. pos — ранняя коррекция хуже поздней."""
    def __init__(self, scenario):
        self.scenario = scenario

    def margins(self, messages, meta, cell):
        f = FACTS[cell[0]]
        text = messages[1]["content"]
        lines = [l.split(": ", 1)[1] if ": " in l else l
                 for l in text.split("\n") if l.startswith("Note ")]
        asserts = [l for l in lines if not l.startswith(CORRECTION_MARKERS)]
        corrs = [l for l in lines if l.startswith(CORRECTION_MARKERS)]
        believed = any(f["false"] in l for l in asserts)
        names_false = any(f["false"] in l for l in corrs)
        # ранняя коррекция = после неё ещё идут подкрепления
        idx = next((i for i, l in enumerate(lines) if l.startswith(CORRECTION_MARKERS)), None)
        early = idx is not None and idx < len(lines) - 1
        h = int(hashlib.sha256(text.encode()).hexdigest()[:8], 16)
        m = -0.5 + ((h % 1000) / 1000.0 - 0.5) * 0.4
        if names_false:
            m -= 3.0
        if believed:
            m -= 1.5
            if names_false:
                m += 2.0            # называние лжи помогает ремонту (оба сценария)
            if early and self.scenario == "pos":
                m -= 4.0
        return -20.0 + m, -20.0, True, 2, 2


class HFScorer:
    def __init__(self):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer
        self.torch = torch
        self.tok = AutoTokenizer.from_pretrained(MODEL_ID, revision=MODEL_REV)
        self.model = AutoModelForCausalLM.from_pretrained(
            MODEL_ID, revision=MODEL_REV, torch_dtype=torch.bfloat16, device_map="auto")
        self.model.eval()

    def margins(self, messages, meta, cell):
        torch = self.torch
        f = FACTS[cell[0]]
        prompt = self.tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        ids_p = self.tok(prompt, add_special_tokens=False)["input_ids"]
        outs, oks, ns = [], [], []
        for ans in (f["true"], f["false"]):
            ids_f = self.tok(prompt + ans, add_special_tokens=False)["input_ids"]
            ok = ids_f[:len(ids_p)] == ids_p
            if not ok:
                ids_f = ids_p + self.tok(ans, add_special_tokens=False)["input_ids"]
            with torch.no_grad():
                t = torch.tensor([ids_f], device=self.model.device)
                lp = torch.log_softmax(self.model(t).logits[0].float(), dim=-1)
            outs.append(sum(float(lp[i - 1, ids_f[i]]) for i in range(len(ids_p), len(ids_f))))
            oks.append(ok); ns.append(len(ids_f) - len(ids_p))
        return outs[0], outs[1], (oks[0] and oks[1]), ns[0], ns[1]


def run(scorer, out_dir, name):
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, "runs.jsonl")
    total = len(FACTS) * len(VARIANTS) * len(SEEDS) * len(ARMS)
    n, t0 = 0, time.time()
    with open(path, "w", encoding="utf-8") as fh:
        for fi in range(len(FACTS)):
            for vname in VARIANTS:
                for s in SEEDS:
                    for arm in ARMS:
                        cell = (fi, vname, s, arm)
                        msgs, meta = build_context(fi, vname, s, arm)
                        sha = hashlib.sha256(json.dumps(msgs, ensure_ascii=False).encode()).hexdigest()
                        try:
                            lc, lf, pok, n1, n2 = scorer.margins(msgs, meta, cell)
                            ok = lc is not None and lf is not None and lc == lc and lf == lf
                        except Exception:
                            lc = lf = None; pok, n1, n2, ok = False, 0, 0, False
                        fh.write(json.dumps({
                            "fact": FACTS[fi]["id"], "fact_idx": fi, "variant": vname,
                            "seed": s, "arm": arm, "lp_correct": lc, "lp_false": lf,
                            "margin": (lc - lf) if ok else None, "prefix_ok": bool(pok),
                            "n_ans_tokens": [n1, n2], "n_notes": meta["n_notes"],
                            "ctx_chars": meta["ctx_chars"], "ctx_sha256": sha,
                            "technical_failure": (not ok)}, ensure_ascii=False) + "\n")
                        n += 1
                        if n % 300 == 0:
                            el = time.time() - t0
                            print("  %d/%d %.0f%%  %.1f мин, осталось ~%.1f мин"
                                  % (n, total, 100.0*n/total, el/60, (el/n*(total-n))/60), flush=True)
    man = {"spec": SPEC_VERSION, "model": MODEL_ID, "revision": MODEL_REV, "scorer": name,
           "k": K, "variants": list(VARIANTS), "seeds": SEEDS, "arms": ARMS,
           "n_facts": len(FACTS), "n_rows": n,
           "runner_sha256": hashlib.sha256(open(os.path.abspath(__file__), "rb").read()).hexdigest(),
           "no_generation": True, "teacher_forcing_only": True,
           "elapsed_sec": round(time.time()-t0, 1),
           "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(t0))}
    if name == "hf":
        try:
            import torch, transformers  # noqa
            man.update({"torch": torch.__version__, "transformers": transformers.__version__,
                        "cuda_device": torch.cuda.get_device_name(0), "dtype": "bfloat16"})
        except Exception:
            pass
    json.dump(man, open(os.path.join(out_dir, "manifest.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    print("rows:", n, "->", path, "за %.1f мин" % ((time.time()-t0)/60))
    return path


def selftest():
    import tempfile, e5_analyze as A
    ok_all = True
    for scen, exp in (("pos", True), ("neg", False)):
        d = tempfile.mkdtemp(prefix="e5_%s_" % scen)
        run(StubScorer(scen), d, "stub-" + scen)
        res = A.analyze(os.path.join(d, "runs.jsonl"))
        g = res["gates"]
        ok = g["position_effect_pass"] == exp and g["naming_effect_pass"]
        ok_all = ok_all and ok
        print("[selftest %s] позиция=%s (ждали %s) называние=%s -> %s"
              % (scen, g["position_effect_pass"], exp, g["naming_effect_pass"],
                 "PASS" if ok else "FAIL"))
        p = res["primary"]
        print("   позиция: %+.3f CI95 [%+.3f, %+.3f] | называние: %+.3f CI95 [%+.3f, %+.3f]"
              % (p["position"]["mean"], p["position"]["ci95"][0], p["position"]["ci95"][1],
                 p["naming"]["mean"], p["naming"]["ci95"][0], p["naming"]["ci95"][1]))
    print("SELFTEST:", "PASS" if ok_all else "FAIL")
    return 0 if ok_all else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--stub", choices=["pos", "neg"])
    ap.add_argument("--out", default="e5_out")
    a = ap.parse_args()
    if a.selftest:
        sys.exit(selftest())
    run(StubScorer(a.stub) if a.stub else HFScorer(), a.out,
        ("stub-" + a.stub) if a.stub else "hf")


if __name__ == "__main__":
    main()
