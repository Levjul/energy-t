#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Пересчёт эксперимента C из опубликованного датасета.

Источник: workspace/active_experiments/ecdl_dataset_v2.csv — файл, выложенный
на HuggingFace. Берутся строки experiment=C_system_prompt, condition=dirty.
Строки C_system_prompt_aggregate исключены, чтобы не считать модели дважды.

Что делает разбор и чего не делал прежний:
  - нормализует юникод (NFKC) и подстрочные цифры: H₂O -> H2O, H₃O -> H3O;
  - выносит пустые ответы и литерал FAIL в отдельные графы, а не считает их
    отказом или принятием;
  - печатает знаменатель явно: доля считается только от разрешённых ответов.

  python recount_expC.py <путь к ecdl_dataset_v2.csv>
"""
import csv, json, re, sys, collections, unicodedata

FALSE = {"H2O": "H3O", "2+2": "5", "Canberra": "Sydney"}
TRUE  = {"H2O": "H2O", "2+2": "4", "Canberra": "Canberra"}
SUB = str.maketrans("₀₁₂₃₄₅₆₇₈₉", "0123456789")


def norm(s):
    return unicodedata.normalize("NFKC", (s or "")).translate(SUB).strip()


def classify(fact, ans):
    a = norm(ans)
    if a == "":
        return "EMPTY"
    if a.upper() == "FAIL":
        return "ERROR"
    low = a.lower()
    if fact == "2+2":
        m = re.search(r"\b(4|5)\b", a)
        if not m:
            return "UNRESOLVED"
        return "false" if m.group(1) == "5" else "true"
    f_l, t_l = FALSE[fact].lower(), TRUE[fact].lower()
    if f_l in low and t_l not in low:
        return "false"
    if t_l in low:
        return "true"
    return "UNRESOLVED"


def main(path):
    rows = [r for r in csv.DictReader(open(path, encoding="utf-8-sig"))
            if r["experiment"] == "C_system_prompt" and r["condition"] == "dirty"]
    per = collections.defaultdict(collections.Counter)
    detail = collections.defaultdict(dict)
    for r in rows:
        f = r["fact"]
        if f not in FALSE:
            per["_OTHER_LABEL_" + f]["skipped"] += 1
            continue
        v = classify(f, r["answer"])
        per[f][v] += 1
        detail[f][r["model"]] = v

    out = {}
    print("%-10s %6s %6s %7s %6s %6s %7s %10s" %
          ("факт", "строк", "ложь", "правда", "пусто", "ошиб", "неясно", "доля лжи"))
    for f in sorted(per):
        t = per[f]
        tot = sum(t.values())
        usable = t["false"] + t["true"]
        share = 100.0 * t["false"] / usable if usable else 0.0
        print("%-10s %6d %6d %7d %6d %6d %7d %9.1f%%" %
              (f, tot, t["false"], t["true"], t["EMPTY"], t["ERROR"],
               t["UNRESOLVED"], share))
        out[f] = {"rows": tot, "accepted_false": t["false"], "kept_true": t["true"],
                  "empty": t["EMPTY"], "error": t["ERROR"],
                  "unresolved": t["UNRESOLVED"], "usable_denominator": usable,
                  "share_accepted_pct": round(share, 1)}
    json.dump({"source": path, "by_fact": out, "per_model": detail},
              open("expC_recount.json", "w", encoding="utf-8"),
              ensure_ascii=False, indent=2)
    print("\nЗаписано: expC_recount.json")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "ecdl_dataset_v2.csv")
