#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A2 — меняет ли загрязнённый контекст объём генерации.
Преднрегистрация: PREREGISTRATION.md (A2_v0.1), sha256 в PREREG_SHA256.txt.

Данные: существующие прогоны res_*.json. Новых прогонов нет.
Все правила учёта заданы в преднрегистрации и здесь только исполняются.

  python a2_analyze.py --root <путь к 2026-0*> --out a2_raw.json
"""
import argparse, glob, json, os, random, re
import statistics as st

BOOT_N = 10000
BOOT_SEED = 20260924
EFFECT_MIN = 1.0          # токен — неделимая единица расхода
MAX_EXCLUDED_SHARE = 0.20


def model_name(path):
    b = os.path.basename(path)
    return re.sub(r"\.json$", "", re.sub(r"^res_", "", b))


def usable(side):
    """Правило учёта незавершённых из преднрегистрации, п.3."""
    if not isinstance(side, dict):
        return None, "NO_SIDE"
    try:
        ch = side["choices"][0]
    except (KeyError, IndexError, TypeError):
        return None, "NO_CHOICE"
    fr = ch.get("finish_reason")
    if fr != "stop":
        return None, "FINISH_%s" % fr
    txt = (ch.get("message") or {}).get("content")
    if not txt:
        return None, "NO_TEXT"
    u = side.get("usage") or {}
    ct = u.get("completion_tokens")
    if not ct:
        return None, "NO_COMPLETION_TOKENS"
    return {"completion_tokens": ct,
            "prompt_tokens": u.get("prompt_tokens"),
            "text": txt}, "OK"


def bootstrap_ci(vals, n=BOOT_N, seed=BOOT_SEED):
    vals = [v for v in vals if v is not None]
    if len(vals) < 2:
        return (float("nan"), float("nan"))
    rng = random.Random(seed)
    k = len(vals)
    means = sorted(st.fmean(rng.choice(vals) for _ in range(k)) for _ in range(n))
    return (means[int(0.025 * n)], means[min(int(0.975 * n), n - 1)])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--out", default="a2_raw.json")
    a = ap.parse_args()

    files = sorted(glob.glob(os.path.join(a.root, "2026-0*", "res_*.json")))
    pairs, excluded = [], []

    for fp in files:
        try:
            data = json.load(open(fp, encoding="utf-8"))
        except Exception as exc:                              # noqa: BLE001
            excluded.append({"file": os.path.basename(fp), "fact": None,
                             "reason": "READ_%s" % type(exc).__name__})
            continue
        if not isinstance(data, list):
            excluded.append({"file": os.path.basename(fp), "fact": None,
                             "reason": "NOT_A_LIST"})
            continue
        mdl = model_name(fp)
        for rec in data:
            if not isinstance(rec, dict):
                continue
            fact = rec.get("fact")
            c, rc = usable(rec.get("clean"))
            d, rd = usable(rec.get("dirty"))
            if c is None or d is None:
                excluded.append({"model": mdl, "fact": fact,
                                 "reason_clean": rc, "reason_dirty": rd})
                continue
            pairs.append({
                "model": mdl, "fact": fact,
                "completion_clean": c["completion_tokens"],
                "completion_dirty": d["completion_tokens"],
                "dG": d["completion_tokens"] - c["completion_tokens"],
                "prompt_clean": c["prompt_tokens"],
                "prompt_dirty": d["prompt_tokens"],
                "dPrompt": (d["prompt_tokens"] - c["prompt_tokens"])
                            if (c["prompt_tokens"] and d["prompt_tokens"]) else None,
                "text_clean": c["text"][:200],
                "text_dirty": d["text"][:200],
            })

    n_pairs, n_excl = len(pairs), len(excluded)
    total = n_pairs + n_excl
    excl_share = (n_excl / total) if total else 1.0

    # кластер — модель
    by_model = {}
    for p in pairs:
        by_model.setdefault(p["model"], []).append(p["dG"])
    cluster_means = {m: st.fmean(v) for m, v in by_model.items()}
    vals = list(cluster_means.values())
    mean_dG = st.fmean(vals) if vals else float("nan")
    ci = bootstrap_ci(vals)
    zero_covered = (ci[0] <= 0.0 <= ci[1])

    if excl_share > MAX_EXCLUDED_SHARE:
        verdict = ("ПЕРВИЧНЫЙ ПОКАЗАТЕЛЬ НЕДЕЙСТВИТЕЛЕН: исключено %.1f%% пар "
                   "(порог 20%%)" % (excl_share * 100))
    elif zero_covered:
        verdict = ("ЭФФЕКТА НЕТ: ноль накрыт интервалом. Загрязнение контекста "
                   "не меняет объём генерации на этих данных")
    elif abs(mean_dG) < EFFECT_MIN:
        verdict = ("НЕОПРЕДЕЛЁННОСТЬ: различие отличимо от нуля, но меньше "
                   "одного токена — физического смысла при переводе в джоули нет")
    else:
        verdict = ("ЭФФЕКТ ЕСТЬ: объём генерации при загрязнённом контексте "
                   "отличается на %+.2f токена" % mean_dG)

    # вторичное
    dprompt = [p["dPrompt"] for p in pairs if p["dPrompt"] is not None]
    same_text = sum(1 for p in pairs if p["text_clean"] == p["text_dirty"])
    ident_dG0 = sum(1 for p in pairs if p["dG"] == 0)

    out = {
        "spec": "A2_v0.1_2026-09-24",
        "preregistration_sha256_file": "PREREG_SHA256.txt",
        "n_files": len(files),
        "n_pairs_used": n_pairs,
        "n_pairs_excluded": n_excl,
        "excluded_share": round(excl_share, 4),
        "n_clusters_models": len(cluster_means),
        "primary": {
            "mean_dG_tokens": round(mean_dG, 4) if mean_dG == mean_dG else None,
            "ci95": [round(ci[0], 4), round(ci[1], 4)],
            "zero_covered": zero_covered,
            "effect_min": EFFECT_MIN,
        },
        "secondary": {
            "share_dG_zero": round(ident_dG0 / n_pairs, 4) if n_pairs else None,
            "mean_dPrompt_tokens": round(st.fmean(dprompt), 3) if dprompt else None,
            "share_identical_text": round(same_text / n_pairs, 4) if n_pairs else None,
            "completion_clean_median": st.median(
                [p["completion_clean"] for p in pairs]) if pairs else None,
            "completion_dirty_median": st.median(
                [p["completion_dirty"] for p in pairs]) if pairs else None,
        },
        "verdict": verdict,
        "cluster_means": {k: round(v, 4) for k, v in sorted(cluster_means.items())},
        "pairs": pairs,
        "excluded": excluded,
    }
    json.dump(out, open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

    print("файлов: %d | пар: %d | исключено: %d (%.1f%%) | кластеров-моделей: %d"
          % (len(files), n_pairs, n_excl, excl_share * 100, len(cluster_means)))
    print("среднее dG = %+.3f токена, CI95 [%+.3f, %+.3f], ноль накрыт: %s"
          % (mean_dG, ci[0], ci[1], zero_covered))
    print("доля пар с dG == 0: %s" % out["secondary"]["share_dG_zero"])
    print("медиана completion: clean %s, dirty %s"
          % (out["secondary"]["completion_clean_median"],
             out["secondary"]["completion_dirty_median"]))
    print("средняя разность длины промпта: %s токена"
          % out["secondary"]["mean_dPrompt_tokens"])
    print()
    print(verdict)
    print("сырое: %s" % a.out)


if __name__ == "__main__":
    main()
